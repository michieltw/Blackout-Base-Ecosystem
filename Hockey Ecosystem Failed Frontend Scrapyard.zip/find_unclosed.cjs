const fs = require('fs');
const text = fs.readFileSync('src/components/CompetitieDashboard.tsx', 'utf8');

let tags = [];
let i = 0;
let line = 1;
let col = 1;

while (i < text.length) {
  if (text[i] === '\n') {
    line++;
    col = 1;
    i++;
    continue;
  }
  
  if (text.substr(i, 4) === '<div') {
    let endIdx = i;
    let isSelfClosing = false;
    let inString = false;
    let stringChar = '';
    while (endIdx < text.length) {
      const c = text[endIdx];
      if (inString) {
        if (c === stringChar) inString = false;
      } else {
        if (c === '"' || c === "'") {
          inString = true;
          stringChar = c;
        } else if (c === '>') {
          if (text[endIdx - 1] === '/') isSelfClosing = true;
          break;
        }
      }
      endIdx++;
    }
    if (!isSelfClosing) {
      tags.push({ type: 'div', line, col });
    }
    i = endIdx + 1;
    continue;
  }
  
  if (text.substr(i, 6) === '</div>') {
    if (tags.length > 0 && tags[tags.length - 1].type === 'div') {
      tags.pop();
    } else {
      console.log(`Unmatched </div> at line ${line}`);
    }
    i += 6;
    continue;
  }
  
  i++;
  col++;
}

console.log("Unclosed <div> tags:");
tags.forEach(t => console.log(`Line ${t.line}`));
