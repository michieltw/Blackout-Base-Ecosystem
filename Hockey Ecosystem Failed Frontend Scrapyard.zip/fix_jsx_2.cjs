const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx',
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  
  // Rule: `<tag ... attr="val"` followed by newline -> add `>`
  // Using a regex with multiline: 
  // Look for any line that has an unclosed `<tag` and ends with `"`.
  // Actually simpler:
  // if we see `className="[a-zA-Z0-9\s\-_]+"` and it's followed by a newline or `<` or `{`
  // We should append `>` to it.
  
  text = text.replace(/className="([^"]*)"\s*$/gm, 'className="$1">');
  text = text.replace(/className="([^"]*)"\s+(<[A-Za-z\/])/g, 'className="$1">\n$2');
  text = text.replace(/className="([^"]*)"\s+(\{)/g, 'className="$1">$2');
  
  // Same for other common attributes that might have been the last one
  // like `alt="something"`
  text = text.replace(/alt="([^"]*)"\s*$/gm, 'alt="$1">');
  text = text.replace(/alt="([^"]*)"\s+(<[A-Za-z\/])/g, 'alt="$1">\n$2');
  text = text.replace(/alt="([^"]*)"\s+(\{)/g, 'alt="$1">$2');

  // Same for `type="button"`
  text = text.replace(/type="([^"]*)"\s*$/gm, 'type="$1">');
  text = text.replace(/type="([^"]*)"\s+(<[A-Za-z\/])/g, 'type="$1">\n$2');
  text = text.replace(/type="([^"]*)"\s+(\{)/g, 'type="$1">$2');
  
  // For `src="..."`
  text = text.replace(/src="([^"]*)"\s*$/gm, 'src="$1">');
  text = text.replace(/src="([^"]*)"\s+(<[A-Za-z\/])/g, 'src="$1">\n$2');
  text = text.replace(/src="([^"]*)"\s+(\{)/g, 'src="$1">$2');

  // For text content:
  // `className="font-bold text-sm text-slate-800"Technisch Paspoort</h3>` -> `...800">Technisch...`
  text = text.replace(/className="([^"]*)"([A-Za-z0-9])/g, 'className="$1">$2');
  
  fs.writeFileSync(file, text);
});
