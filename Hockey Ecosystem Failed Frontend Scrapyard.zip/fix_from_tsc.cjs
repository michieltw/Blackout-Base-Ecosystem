const fs = require('fs');

// We will just run regexes to fix the remaining specific things.
// In ManagerDashboard:
let text = fs.readFileSync('src/components/ManagerDashboard.tsx', 'utf8');
text = text.replace(/className="([^"]*)"title="([^"]*)"/g, 'className="$1" title="$2">');
text = text.replace(/className="([^"]*)"\s*De-select/g, 'className="$1">\nDe-select');
text = text.replace(/className="([^"]*)"\s*Verplaats/g, 'className="$1">\nVerplaats');
text = text.replace(/src="([^"]*)"\s*className="([^"]*)"\s*$/gm, 'src="$1" className="$2" />');

// also `error TS1005: ')' expected.` at 446
// Let's just fix ManagerDashboard
fs.writeFileSync('src/components/ManagerDashboard.tsx', text);

