const { Project, SyntaxKind } = require('ts-morph');
const project = new Project();
project.addSourceFilesAtPaths("src/**/*.tsx");

project.getSourceFiles().forEach(sourceFile => {
  let hasChanges = false;
  
  // Remove JSX attribute isDeveloperMode={...}
  const jsxElements = [...sourceFile.getDescendantsOfKind(SyntaxKind.JsxElement), ...sourceFile.getDescendantsOfKind(SyntaxKind.JsxSelfClosingElement)];
  jsxElements.forEach(jsx => {
    const attr = jsx.getAttribute('isDeveloperMode');
    if (attr) {
      attr.remove();
      hasChanges = true;
    }
  });

  // Remove PropertySignature `isDeveloperMode?: boolean;` from interfaces
  const interfaces = sourceFile.getInterfaces();
  interfaces.forEach(intf => {
    const prop = intf.getProperty('isDeveloperMode');
    if (prop) {
      prop.remove();
      hasChanges = true;
    }
  });

  // Remove isDeveloperMode = false from function parameters
  const functions = [...sourceFile.getFunctions(), ...sourceFile.getArrowFunctions()];
  functions.forEach(func => {
    func.getParameters().forEach(param => {
      // It's usually inside an object destructuring
      if (param.getNameNode().getKind() === SyntaxKind.ObjectBindingPattern) {
        const elements = param.getNameNode().getElements();
        elements.forEach(element => {
          if (element.getNameNode().getText() === 'isDeveloperMode') {
            element.remove();
            hasChanges = true;
          }
        });
      }
    });
  });

  if (hasChanges) {
    sourceFile.saveSync();
    console.log(`Updated ${sourceFile.getFilePath()}`);
  }
});
