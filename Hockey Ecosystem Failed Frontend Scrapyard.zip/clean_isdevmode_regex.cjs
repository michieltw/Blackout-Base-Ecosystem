const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else {
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let original = content;

  // Remove JSX prop isDeveloperMode={...}
  content = content.replace(/\s*isDeveloperMode=\{[^}]+\}/g, '');
  // Remove JSX prop isDeveloperMode
  content = content.replace(/\s*isDeveloperMode(\s|>|\/)/g, '$1');
  
  // Remove interface property
  content = content.replace(/\s*isDeveloperMode\s*\?:\s*boolean\s*;/g, '');
  
  // Remove object destructuring param
  content = content.replace(/,\s*isDeveloperMode\s*=\s*(false|true)/g, '');
  content = content.replace(/isDeveloperMode\s*=\s*(false|true)\s*,?/g, '');
  content = content.replace(/,\s*isDeveloperMode/g, '');

  if (content !== original) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${file}`);
  }
});
