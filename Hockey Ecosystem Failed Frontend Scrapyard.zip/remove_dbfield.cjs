const { Project, SyntaxKind } = require('ts-morph');

const project = new Project();
project.addSourceFilesAtPaths("src/**/*.tsx");

const files = project.getSourceFiles();

files.forEach(sourceFile => {
  let hasChanges = false;
  
  // Remove import { DbField } from ...
  const imports = sourceFile.getImportDeclarations();
  imports.forEach(imp => {
    const namedImports = imp.getNamedImports();
    namedImports.forEach(ni => {
      if (ni.getName() === 'DbField') {
        if (namedImports.length === 1) {
          imp.remove();
        } else {
          ni.remove();
        }
        hasChanges = true;
      }
    });
  });

  // Find all DbField elements and replace them with their value prop
  const jsxElements = sourceFile.getDescendantsOfKind(SyntaxKind.JsxSelfClosingElement);
  jsxElements.forEach(jsx => {
    if (jsx.getTagNameNode().getText() === 'DbField') {
      const valueAttr = jsx.getAttribute('value');
      if (valueAttr && valueAttr.getKind() === SyntaxKind.JsxAttribute) {
        const init = valueAttr.getInitializer();
        let replacement = '';
        if (init) {
          if (init.getKind() === SyntaxKind.JsxExpression) {
            replacement = init.getExpression().getText();
            // if replacement is itself JSX element, we might need to wrap it? No, we can just replace the whole DbField with `{replacement}` if it's an expression
            // Wait, we are replacing a JSX element with another JSX element/expression.
            // If the parent is a JsxElement (e.g. <div><DbField /></div>), we can replace `<DbField/>` with `{expression}` or if the expression is a JSX element, just the JSX element.
            if (init.getExpression().getKind() === SyntaxKind.JsxElement || init.getExpression().getKind() === SyntaxKind.JsxSelfClosingElement || init.getExpression().getKind() === SyntaxKind.JsxFragment) {
              replacement = init.getExpression().getText();
            } else {
              replacement = `{${replacement}}`;
            }
          } else if (init.getKind() === SyntaxKind.StringLiteral) {
            replacement = init.getText();
          }
        }
        jsx.replaceWithText(replacement);
        hasChanges = true;
      }
    }
  });

  if (hasChanges) {
    sourceFile.saveSync();
    console.log(`Updated ${sourceFile.getFilePath()}`);
  }
});
