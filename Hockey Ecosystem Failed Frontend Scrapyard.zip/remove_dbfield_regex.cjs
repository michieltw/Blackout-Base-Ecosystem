const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  
  // A regex to match <DbField ... value={ <span>...</span> } ... />
  // This is tricky because it spans multiple lines.
  
  // We can just find `<DbField` and match until `/>` or `</DbField>`
  // Let's do it manually using indices.
  let result = '';
  let i = 0;
  while (i < text.length) {
    let idx = text.indexOf('<DbField', i);
    if (idx === -1) {
      result += text.substring(i);
      break;
    }
    result += text.substring(i, idx);
    
    // Find the end of DbField
    let endIdx = idx;
    let braces = 0;
    let inString = false;
    let stringChar = '';
    while (endIdx < text.length) {
      let c = text[endIdx];
      if (inString) {
        if (c === stringChar) inString = false;
      } else {
        if (c === '"' || c === "'") {
          inString = true;
          stringChar = c;
        } else if (c === '{') {
          braces++;
        } else if (c === '}') {
          braces--;
        } else if (c === '>' && braces === 0) {
          break;
        }
      }
      endIdx++;
    }
    
    let tag = text.substring(idx, endIdx + 1);
    // Find value={ ... }
    let valueMatch = tag.match(/value=\{([\s\S]*)\}\s*(sourceType|isDeveloperMode|\/>)/);
    if (valueMatch) {
      let value = valueMatch[1].trim();
      // the regex value match might be too greedy if there's multiple `{}`.
      // So we do `{${value}}` if it's not a JSX element.
      // Actually, if it's already JSX, just insert it without `{}`.
      result += `{${value}}`;
    } else {
      // fallback if regex didn't work
      let valStart = tag.indexOf('value={');
      if (valStart !== -1) {
         // extract
         result += '{/* DbField removed */}';
      }
    }
    
    i = endIdx + 1;
  }
  
  fs.writeFileSync(file, result);
});
