const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx',
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  
  // Find `">` at the end of a line, or before another attribute, and remove it if the tag isn't supposed to close there.
  // The mistake was adding `>` after any string literal that ended a line.
  // A jsx tag should only close with `>` or `/>`.
  // If we have `">\n  attr=` or `">\n  />` or `">\n  required`
  
  text = text.replace(/">\s+([a-zA-Z0-9-]+)=/g, '"\n$1=');
  text = text.replace(/">\s+([a-zA-Z0-9-]+)\s*\/>/g, '"\n$1 />');
  text = text.replace(/">\s+\/>/g, '"\n/>');
  text = text.replace(/">\s+required/g, '"\nrequired');
  text = text.replace(/">\s+readOnly/g, '"\nreadOnly');
  text = text.replace(/">\s+disabled/g, '"\ndisabled');
  text = text.replace(/">\s+multiple/g, '"\nmultiple');
  
  // also what about `type="something">` at the end of the line, and then just text? That was handled by fix_jsx_2, it added the `>`. If it was legitimately missing, it's correct.
  
  fs.writeFileSync(file, text);
});
