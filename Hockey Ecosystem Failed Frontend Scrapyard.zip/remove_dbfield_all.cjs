const { Project, SyntaxKind } = require('ts-morph');
const project = new Project();
project.addSourceFilesAtPaths("src/**/*.tsx");

project.getSourceFiles().forEach(sourceFile => {
  let hasChanges = false;
  
  // Remove import
  const imports = sourceFile.getImportDeclarations();
  imports.forEach(imp => {
    if (imp.getModuleSpecifierValue().includes('DbField')) {
      imp.remove();
      hasChanges = true;
    }
  });

  const jsxElements = [...sourceFile.getDescendantsOfKind(SyntaxKind.JsxElement), ...sourceFile.getDescendantsOfKind(SyntaxKind.JsxSelfClosingElement)];
  
  for (let i = jsxElements.length - 1; i >= 0; i--) {
    const jsx = jsxElements[i];
    
    let tagName = '';
    if (jsx.getKind() === SyntaxKind.JsxElement) {
      tagName = jsx.getOpeningElement().getTagNameNode().getText();
    } else {
      tagName = jsx.getTagNameNode().getText();
    }
    
    if (tagName === 'DbField') {
      let attr;
      if (jsx.getKind() === SyntaxKind.JsxElement) {
        attr = jsx.getOpeningElement().getAttribute('value');
      } else {
        attr = jsx.getAttribute('value');
      }
      
      if (attr && attr.getKind() === SyntaxKind.JsxAttribute) {
        const init = attr.getInitializer();
        if (init && init.getKind() === SyntaxKind.JsxExpression) {
          const expr = init.getExpression();
          if (expr) {
            jsx.replaceWithText(`{${expr.getText()}}`);
            hasChanges = true;
          }
        }
      }
    }
  }

  if (hasChanges) {
    sourceFile.saveSync();
    console.log(`Updated ${sourceFile.getFilePath()}`);
  }
});
