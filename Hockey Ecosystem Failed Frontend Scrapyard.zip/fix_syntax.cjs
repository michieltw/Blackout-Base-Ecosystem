const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx',
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  // The remnants are strings like `" dataFlow="..." >` or similar, up to the closing `>`
  // Let's just remove anything matching `\n\s*" dataFlow="[^"]*"\s*>`
  text = text.replace(/" dataFlow="[^"]*"\s*>/g, '');
  text = text.replace(/" dataFlow="[^"]*">/g, '');
  
  // also some might have isDeveloperMode={isDeveloperMode}>
  text = text.replace(/" dataFlow="[^"]*"\s*isDeveloperMode={isDeveloperMode}>/g, '');
  text = text.replace(/" dataFlow="[^"]*"\s*isDeveloperMode>/g, '');
  
  // What about `/>"` ? Just in case
  text = text.replace(/" dataFlow="[^"]*"/g, '');
  
  // Let's also check for standalone `>` that were left behind
  text = text.replace(/"\s*>/g, '"');
  
  // Actually, wait, let's just use a regex to find the exact remnant strings.
  // The remnants look like: `" dataFlow="...`
  // We can just remove lines that start with spaces and `" dataFlow=`
  text = text.replace(/^\s*" dataFlow=.*$/gm, '');
  
  fs.writeFileSync(file, text);
});
