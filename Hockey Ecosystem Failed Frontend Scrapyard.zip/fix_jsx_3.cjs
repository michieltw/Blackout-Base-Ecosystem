const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx',
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  
  // Undo the damage from fix_jsx_2.cjs
  // If we have `type="something">` but the next line is an attribute (not a tag)
  // We can just remove the `>`.
  text = text.replace(/type="([^"]*)">\s+value=/g, 'type="$1"\nvalue=');
  text = text.replace(/type="([^"]*)">\s+onChange=/g, 'type="$1"\nonChange=');
  text = text.replace(/type="([^"]*)">\s+checked=/g, 'type="$1"\nchecked=');
  text = text.replace(/type="([^"]*)">\s+placeholder=/g, 'type="$1"\nplaceholder=');
  text = text.replace(/type="([^"]*)">\s+className=/g, 'type="$1"\nclassName=');
  text = text.replace(/type="([^"]*)">\s+required/g, 'type="$1"\nrequired');
  text = text.replace(/type="([^"]*)">\s+maxLength/g, 'type="$1"\nmaxLength');

  // Same for className
  text = text.replace(/className="([^"]*)">\s+required/g, 'className="$1"\nrequired');
  text = text.replace(/className="([^"]*)">\s+maxLength/g, 'className="$1"\nmaxLength');
  text = text.replace(/className="([^"]*)">\s+value=/g, 'className="$1"\nvalue=');
  text = text.replace(/className="([^"]*)">\s+onChange=/g, 'className="$1"\nonChange=');
  text = text.replace(/className="([^"]*)">\s+onClick=/g, 'className="$1"\nonClick=');
  text = text.replace(/className="([^"]*)">\s+title=/g, 'className="$1"\ntitle=');
  
  // For `src="..."`
  text = text.replace(/src="([^"]*)">\s+alt=/g, 'src="$1"\nalt=');
  text = text.replace(/src="([^"]*)">\s+className=/g, 'src="$1"\nclassName=');
  
  // If a tag is like `<img src="..." alt="..." className="..." />`
  // `fix_jsx_2` might have made it `<img src="...">\nalt="...">\nclassName="...">\n/>`!
  // Wait, `fix_jsx_2` matched `\s*$` so only at the end of the line.
  
  // For `alt="..."`
  text = text.replace(/alt="([^"]*)">\s+className=/g, 'alt="$1"\nclassName=');
  text = text.replace(/alt="([^"]*)">\s+style=/g, 'alt="$1"\nstyle=');
  text = text.replace(/alt="([^"]*)">\s+referrerPolicy=/g, 'alt="$1"\nreferrerPolicy=');

  fs.writeFileSync(file, text);
});
