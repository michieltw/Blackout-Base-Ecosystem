import { AppDatabase } from '../types';

export const initialDatabase: AppDatabase = {
  currentUser: {
    id: 'user-michiel',
    username: 'Michiel Waalboer',
    email: 'beheerder@ghl.nl',
    systemRole: 'MultiLeagueOfficer', // Default to highest role so the user can see everything, with easy toggle in the UI!
    personId: 'person-michiel'
  },
  persons: [
    {
      id: 'person-michiel',
      name: 'Michiel Waalboer',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_male.png?v=1784405792',
      birthdate: '1988-11-12',
      nationality: 'Nederlands',
      bio: 'Hoofdstrateeg van de GIJS Groningen House League en teammanager.',
      roles: ['Manager'], // Can be customized in the profile!
      equipment: [
        {
          id: 'eq-michiel-1',
          type: 'stick',
          brand: 'Bauer',
          model: 'Nexus Sync',
          specifications: { flex: 77, curve: 'P92' },
          condition: 95
        }
      ],
      stats: {
        gamesPlayed: 14,
        goals: 8,
        assists: 12,
        points: 20,
        penaltyMinutes: 6,
        rating: 84,
        speed: 82,
        shooting: 85,
        passing: 88,
        defense: 75,
        physical: 72
      },
      playerPool: 'None',
      teamIds: ['team-amstel']
    },
    {
      id: 'person-sven',
      name: 'Sven van den Broek',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: '1992-04-23',
      nationality: 'Nederlands',
      bio: 'Ervaren ijshockeyrot die zowel op het ijs de lijnen uitzet als langs de bank de tactiek bepaalt.',
      roles: ['Player', 'Manager'], // Both Player & Manager!
      equipment: [
        {
          id: 'eq-sven-1',
          type: 'stick',
          brand: 'CCM',
          model: 'Ribcor Trigger 8 Pro',
          specifications: { flex: 85, curve: 'P29' },
          condition: 88
        },
        {
          id: 'eq-sven-2',
          type: 'skates',
          brand: 'Bauer',
          model: 'Vapor Hyperlite 2',
          specifications: { size: 42.5 },
          condition: 92
        }
      ],
      stats: {
        gamesPlayed: 24,
        goals: 12,
        assists: 18,
        points: 30,
        penaltyMinutes: 14,
        rating: 89,
        speed: 81,
        shooting: 86,
        passing: 91,
        defense: 83,
        physical: 80
      },
      playerPool: 'None',
      teamIds: ['team-tilburg'],
      managedTeamId: 'team-tilburg'
    },
    {
      id: 'person-lars',
      name: 'Lars de Graaf',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_goalie_male.png?v=1784405792',
      birthdate: '1998-08-15',
      nationality: 'Belg',
      bio: 'Snelheidswonder en flexibele sluitpost (Goalie). Staat bekend als een van de meest betrouwbare keepers.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-lars-1',
          type: 'stick',
          brand: 'Warrior',
          model: 'Alpha LX2 Pro',
          specifications: { flex: 75, curve: 'W03' },
          condition: 75
        }
      ],
      stats: {
        gamesPlayed: 18,
        goals: 1,
        assists: 9,
        points: 10,
        penaltyMinutes: 8,
        rating: 81,
        speed: 92,
        shooting: 80,
        passing: 76,
        defense: 65,
        physical: 68
      },
      playerPool: 'Leenspelers', // Part of a player pool!
      teamIds: ['team-amstel', 'team-heerenveen'] // Plays in multiple teams/competitions!
    },
    {
      id: 'person-anke',
      name: 'Anke de Vries',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_fem.png?v=1784405790',
      birthdate: '1985-05-30',
      nationality: 'Nederlands',
      bio: 'Oud-speelster en nu fulltime League Officer voor de Groningen House League. Streeft naar ultieme sportiviteit.',
      roles: ['Manager'],
      playerPool: 'None',
      teamIds: []
    },
    {
      id: 'person-mika',
      name: 'Mika Karppinen',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: '1995-01-10',
      nationality: 'Fins',
      bio: 'Geïmporteerde Finse sluipschutter met een vlijmscherp schot en een ijzersterke stick.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-mika-1',
          type: 'stick',
          brand: 'Sherwood',
          model: 'Code TMP 1',
          specifications: { flex: 95, curve: 'PP26' },
          condition: 90
        }
      ],
      stats: {
        gamesPlayed: 20,
        goals: 22,
        assists: 11,
        points: 33,
        penaltyMinutes: 12,
        rating: 87,
        speed: 84,
        shooting: 93,
        passing: 79,
        defense: 70,
        physical: 78
      },
      playerPool: 'None',
      teamIds: ['team-amstel']
    },
    {
      id: 'person-jordy',
      name: 'Jordy van Oorschot',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: '1996-09-02',
      nationality: 'Nederlands',
      bio: 'Fysiek ijzersterke verdediger. Niet bang om zware duels aan te gaan aan de boarding.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-jordy-1',
          type: 'stick',
          brand: 'Bauer',
          model: 'Supreme Shadow',
          specifications: { flex: 102, curve: 'P88' },
          condition: 82
        }
      ],
      stats: {
        gamesPlayed: 22,
        goals: 3,
        assists: 14,
        points: 17,
        penaltyMinutes: 38,
        rating: 82,
        speed: 76,
        shooting: 72,
        passing: 81,
        defense: 89,
        physical: 90
      },
      playerPool: 'None',
      teamIds: ['team-tilburg']
    },
    {
      id: 'person-danny',
      name: 'Danny van de Velde',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: '2001-12-19',
      nationality: 'Nederlands',
      bio: 'Jonge talentvolle aanvaller. Staat momenteel in de spelerpool "Leenspelers" te wachten op invalbeurten.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-danny-1',
          type: 'stick',
          brand: 'CCM',
          model: 'Jetspeed FT6 Pro',
          specifications: { flex: 70, curve: 'P28' },
          condition: 98
        }
      ],
      stats: {
        gamesPlayed: 5,
        goals: 2,
        assists: 4,
        points: 6,
        penaltyMinutes: 2,
        rating: 74,
        speed: 88,
        shooting: 75,
        passing: 74,
        defense: 62,
        physical: 60
      },
      playerPool: 'Leenspelers',
      teamIds: ['team-heerenveen']
    },
    {
      id: 'person-esmee',
      name: 'Esmee de Jong',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_fem.png?v=1784405791',
      birthdate: '2002-07-14',
      nationality: 'Nederlands',
      bio: 'Vliegensvlugge vrouwelijke aanvaller met een feilloos gevoel voor positie en snelle counters.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-esmee-1',
          type: 'stick',
          brand: 'Bauer',
          model: 'Vapor Hyperlite 2',
          specifications: { flex: 65, curve: 'P92' },
          condition: 96
        }
      ],
      stats: {
        gamesPlayed: 12,
        goals: 9,
        assists: 15,
        points: 24,
        penaltyMinutes: 4,
        rating: 83,
        speed: 94,
        shooting: 81,
        passing: 87,
        defense: 68,
        physical: 62
      },
      playerPool: 'None',
      teamIds: ['team-amstel']
    },
    {
      id: 'person-sanne',
      name: 'Sanne Bakker',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_goalie_fem.png?v=1784405792',
      birthdate: '1997-10-05',
      nationality: 'Nederlands',
      bio: 'Fenomenale vrouwelijke goalie. Haar reflexen behoren tot de absolute top in de competitie.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-sanne-1',
          type: 'skates',
          brand: 'Bauer',
          model: 'Konekt Goalie Skates',
          specifications: { size: 39 },
          condition: 95
        }
      ],
      stats: {
        gamesPlayed: 15,
        goals: 0,
        assists: 2,
        points: 2,
        penaltyMinutes: 0,
        rating: 88,
        speed: 85,
        shooting: 50,
        passing: 80,
        defense: 92,
        physical: 76
      },
      playerPool: 'None',
      teamIds: ['team-tilburg']
    },
    {
      id: 'person-lucas',
      name: 'Lucas Dupont',
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: '1999-03-14',
      nationality: 'Belg',
      bio: 'Vrije agent op zoek naar een ambitieus team in de Eredivisie of Benelux Cup.',
      roles: ['Player'],
      equipment: [
        {
          id: 'eq-lucas-1',
          type: 'stick',
          brand: 'Bauer',
          model: 'Nexus Sync',
          specifications: { flex: 82, curve: 'P92' },
          condition: 60
        }
      ],
      stats: {
        gamesPlayed: 0,
        goals: 0,
        assists: 0,
        points: 0,
        penaltyMinutes: 0,
        rating: 76,
        speed: 78,
        shooting: 76,
        passing: 75,
        defense: 72,
        physical: 74
      },
      playerPool: 'Vrije Agenten',
      teamIds: []
    }
  ],
  teams: [
    {
      id: 'team-amstel',
      name: 'Red Hot Chilli Slappers',
      city: 'Groningen',
      stadium: 'Kardinge',
      logo: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/HLRHCS.png?v=1783799596',
      primaryColor: '#EF4444', // Red
      secondaryColor: '#1E1B4B', // Navy
      managerId: 'person-michiel', // Michiel is manager of Red Hot Chilli Slappers
      playerIds: ['person-michiel', 'person-lars', 'person-mika', 'person-esmee'],
      tactics: {
        style: 'Aanvallend',
        powerplayFocus: 'Techniek',
        aggression: 75
      },
      leagueIds: ['league-eredivisie']
    },
    {
      id: 'team-tilburg',
      name: 'Green Grizzly',
      city: 'Groningen',
      stadium: 'Kardinge',
      logo: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/HLGreenGrizzly.png?v=1783799596',
      primaryColor: '#10B981', // Green
      secondaryColor: '#1F2937', // Gray
      managerId: 'person-sven', // Sven is player + manager of Green Grizzly
      playerIds: ['person-sven', 'person-jordy', 'person-sanne'],
      tactics: {
        style: 'Verdedigend',
        powerplayFocus: 'Fysiek',
        aggression: 85
      },
      leagueIds: ['league-eredivisie']
    },
    {
      id: 'team-heerenveen',
      name: 'Blue Knightmares',
      city: 'Groningen',
      stadium: 'Kardinge',
      logo: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/HLBlueKnightmares.png?v=1783799596',
      primaryColor: '#3B82F6', // Blue
      secondaryColor: '#FFFFFF', // White
      managerId: null,
      playerIds: ['person-lars', 'person-danny'],
      tactics: {
        style: 'Neutraal',
        powerplayFocus: 'Snelheid',
        aggression: 60
      },
      leagueIds: ['league-benelux']
    },
    {
      id: 'team-denhaag',
      name: 'Emerald Knights',
      city: 'Groningen',
      stadium: 'Kardinge',
      logo: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/HLEmeraldKnights.png?v=1783799596',
      primaryColor: '#059669', // Dark Green
      secondaryColor: '#065F46', // Dark Green
      managerId: null,
      playerIds: [],
      tactics: {
        style: 'Neutraal',
        powerplayFocus: 'Techniek',
        aggression: 65
      },
      leagueIds: ['league-eredivisie', 'league-benelux'] // In both leagues!
    }
  ],
  leagues: [
    {
      id: 'league-eredivisie',
      name: 'Groningen House League',
      season: '2026-2027',
      region: 'Groningen',
      officerId: 'person-anke', // Anke is League Officer
      teamIds: ['team-amstel', 'team-tilburg', 'team-denhaag']
    },
    {
      id: 'league-benelux',
      name: 'Benelux Cup',
      season: '2026',
      region: 'Benelux',
      officerId: 'person-michiel', // Michiel is officer of Benelux Cup
      teamIds: ['team-heerenveen', 'team-denhaag']
    }
  ],
  matches: [
    {
      id: 'match-1',
      leagueId: 'league-eredivisie',
      homeTeamId: 'team-amstel',
      awayTeamId: 'team-tilburg',
      homeScore: 5,
      awayScore: 3,
      status: 'Verwerkt',
      date: '2026-07-15',
      events: [
        { type: 'Goal', time: '04:12', period: 1, personId: 'person-mika', assistPersonId: 'person-michiel' },
        { type: 'Goal', time: '14:30', period: 1, personId: 'person-sven' },
        { type: 'Penalty', time: '18:15', period: 1, personId: 'person-jordy' },
        { type: 'Goal', time: '28:40', period: 2, personId: 'person-mika', assistPersonId: 'person-lars' },
        { type: 'Goal', time: '34:10', period: 2, personId: 'person-sanne' },
        { type: 'Goal', time: '42:15', period: 3, personId: 'person-michiel' },
        { type: 'Goal', time: '48:50', period: 3, personId: 'person-sven' },
        { type: 'Goal', time: '55:20', period: 3, personId: 'person-lars', assistPersonId: 'person-michiel' },
        { type: 'Goal', time: '59:45', period: 3, personId: 'person-mika' }
      ]
    },
    {
      id: 'match-2',
      leagueId: 'league-eredivisie',
      homeTeamId: 'team-tilburg',
      awayTeamId: 'team-denhaag',
      homeScore: 4,
      awayScore: 1,
      status: 'Verwerkt',
      date: '2026-07-18',
      events: [
        { type: 'Goal', time: '12:20', period: 1, personId: 'person-sven', assistPersonId: 'person-jordy' },
        { type: 'Goal', time: '24:15', period: 2, personId: 'person-jordy' },
        { type: 'Goal', time: '39:50', period: 2, personId: 'person-sven' }
      ]
    },
    {
      id: 'match-3',
      leagueId: 'league-eredivisie',
      homeTeamId: 'team-denhaag',
      awayTeamId: 'team-amstel',
      status: 'Gepland',
      date: '2026-07-25'
    },
    {
      id: 'match-4',
      leagueId: 'league-benelux',
      homeTeamId: 'team-heerenveen',
      awayTeamId: 'team-denhaag',
      homeScore: 2,
      awayScore: 2,
      status: 'Verwerkt',
      date: '2026-07-12',
      events: [
        { type: 'Goal', time: '15:10', period: 1, personId: 'person-lars', assistPersonId: 'person-danny' },
        { type: 'Goal', time: '45:30', period: 3, personId: 'person-danny' }
      ]
    }
  ],
  
  // Instellingen
  settings: {
    firstTimeSetup: false,
    generalSettings: {
      theme: 'light',
      language: 'Nederlands',
      maintenanceMode: false
    },
    matchSettings: {
      periodDurationMinutes: 20,
      overtimeEnabled: true,
      mercyRuleEnabled: false
    },
    specificSettings: {
      allowLoanPlayers: true,
      maxPlayersPerTeam: 22,
      requireEquipmentSafetyCheck: true
    }
  },

  // Vereniging
  association: {
    clubs: [
      { id: 'club-gijs', name: 'GIJS Groningen', founded: '1969', president: 'Jan de Vries', teamsCount: 4 }
    ],
    locations: [
      { id: 'loc-kardinge', name: 'Kardinge', address: 'Kardingerplein 1, 9735 AA Groningen', capacity: 2500, hasRentals: true }
    ],
    members: [
      { id: 'member-1', personId: 'person-michiel', membershipType: 'Active', joinDate: '2015-09-01' },
      { id: 'member-2', personId: 'person-sven', membershipType: 'Active', joinDate: '2018-10-15' },
      { id: 'member-3', personId: 'person-lars', membershipType: 'Active', joinDate: '2020-11-01' },
      { id: 'member-4', personId: 'person-anke', membershipType: 'Supporting', joinDate: '2010-08-20' }
    ],
    sponsors: [
      { id: 'spon-1', name: 'Blackout Hockey', logoUrl: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/BOLOGOBLACK.png?v=1784323868', tier: 'Gold', website: 'https://blackouthockey.com' },
      { id: 'spon-2', name: 'Bauer Benelux', logoUrl: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/HLBlueKnightmares.png?v=1783799596', tier: 'Silver', website: 'https://bauer.com' }
    ]
  },

  // Competitie sub-modellen
  seasons: [
    { id: 'season-2026', name: '2026-2027', startDate: '2026-09-01', endDate: '2027-04-30', isActive: true }
  ],
  divisions: [
    { id: 'div-eredivisie', name: 'Eredivisie', playLevel: 'Pro' },
    { id: 'div-eerste', name: 'Eerste Divisie', playLevel: 'Semi-Pro' }
  ],
  pools: [
    { id: 'pool-a', divisionId: 'div-eredivisie', name: 'Poule A', teamIds: ['team-amstel', 'team-tilburg'] },
    { id: 'pool-b', divisionId: 'div-eredivisie', name: 'Poule B', teamIds: ['team-heerenveen', 'team-denhaag'] }
  ],
  standings: [
    {
      leagueId: 'league-eredivisie',
      seasonId: 'season-2026',
      rows: [
        { teamId: 'team-amstel', gamesPlayed: 2, wins: 2, losses: 0, overtimeLosses: 0, points: 6, goalsFor: 10, goalsAgainst: 4 },
        { teamId: 'team-tilburg', gamesPlayed: 2, wins: 1, losses: 1, overtimeLosses: 0, points: 3, goalsFor: 7, goalsAgainst: 6 },
        { teamId: 'team-denhaag', gamesPlayed: 2, wins: 0, losses: 2, overtimeLosses: 0, points: 0, goalsFor: 2, goalsAgainst: 9 }
      ]
    }
  ],

  // Media
  mediaItems: [
    { id: 'media-1', title: 'Seizoensopening Actiefoto', type: 'Foto', url: 'https://images.unsplash.com/photo-1512719994953-eabf50895df7?auto=format&fit=crop&w=800&q=80', uploadedAt: '2026-07-15T10:00:00Z', description: 'Spectaculaire redding tijdens de opening van het seizoen.', relatedMatchId: 'match-1' },
    { id: 'media-2', title: 'Highlight Video Amstel vs Tilburg', type: 'Video', url: 'https://www.w3schools.com/html/mov_bbb.mp4', uploadedAt: '2026-07-16T12:30:00Z', description: 'Alle doelpunten van de spannende wedstrijd.', relatedMatchId: 'match-1' },
    { id: 'media-3', title: 'Livestream GIJS Groningen', type: 'Livestream', url: 'https://www.youtube.com', uploadedAt: '2026-07-20T20:00:00Z', description: 'Live uitzending van de komende matches.' },
    { id: 'media-4', title: 'Huishoudelijk Reglement 2026', type: 'Document', url: 'https://gijsgroningen.nl/reglement.pdf', uploadedAt: '2026-01-01T00:00:00Z', description: 'De officiële regels van de Groningse House League.' }
  ],

  // Social & Hub
  socialPosts: [
    {
      id: 'post-1',
      personId: 'person-michiel',
      content: 'Wat een geweldige start van de Groningen House League! De Chilli Slappers zijn in topvorm, maar de Grizzlies laten zich zeker niet zomaar aan de kant zetten. Succes aan alle teams dit seizoen!',
      image: 'https://images.unsplash.com/photo-1512719994953-eabf50895df7?auto=format&fit=crop&w=800&q=80',
      createdAt: '2026-07-16T09:15:00Z',
      likesCount: 5,
      likesPersonIds: ['person-sven', 'person-lars', 'person-mika'],
      comments: [
        { id: 'comm-1', personId: 'person-sven', content: 'Gefeliciteerd met de winst Michiel! De volgende keer pakken we jullie.', createdAt: '2026-07-16T10:05:00Z' },
        { id: 'comm-2', personId: 'person-mika', content: 'Slappers on fire! Let’s keep this momentum!', createdAt: '2026-07-16T10:30:00Z' }
      ]
    },
    {
      id: 'post-2',
      personId: 'person-sven',
      content: 'Nieuwe skates binnengekomen! Bauer Vapor Hyperlite 2. Getest op de training gisteravond en ze vliegen werkelijk over het ijs. Absolute aanrader voor spelers die snelheid zoeken.',
      createdAt: '2026-07-19T14:20:00Z',
      likesCount: 3,
      likesPersonIds: ['person-michiel', 'person-sanne'],
      comments: []
    }
  ],
  socialNotifications: [
    { id: 'notif-1', personId: 'person-michiel', type: 'Like', title: 'Nieuwe Like', body: 'Sven van den Broek vindt je bericht leuk.', isRead: false, createdAt: '2026-07-16T09:20:00Z' },
    { id: 'notif-2', personId: 'person-michiel', type: 'Comment', title: 'Nieuwe Reactie', body: 'Sven reageerde op je bericht: "Gefeliciteerd met de winst..."', isRead: false, createdAt: '2026-07-16T10:05:00Z' }
  ],
  socialAdvertisements: [
    { id: 'ad-1', sponsorId: 'spon-1', title: 'Blackout Hockey Stick Sale - 20% OFF!', imageUrl: 'https://images.unsplash.com/photo-1580748141549-71748d60bdc5?auto=format&fit=crop&w=600&q=80', targetUrl: 'https://blackouthockey.com', clicks: 142 }
  ],
  socialActivities: [
    { id: 'act-1', personId: 'person-michiel', activityType: 'Goal', description: 'Scoorde een doelpunt in de 3e periode tegen Green Grizzly.', createdAt: '2026-07-15T21:10:00Z' },
    { id: 'act-2', personId: 'person-sven', activityType: 'EquipmentUpdate', description: 'Heeft Bauer Vapor Hyperlite 2 skates toegevoegd aan uitrusting.', createdAt: '2026-07-19T14:15:00Z' }
  ],

  // Expanded fields seed data
  calendarEvents: [
    {
      id: 'cal-1',
      title: 'IJstraining - Techniek & Powerplay',
      type: 'Training',
      date: '2026-07-22',
      time: '20:15 - 21:45',
      location: 'Kardinge',
      description: 'Intensieve training gericht op powerplay-opstellingen en passing-snelheid onder hoge druk. Zorg dat je 30 minuten voor aanvang in de kleedkamer bent.',
      rsvps: {
        'person-michiel': 'Aanwezig',
        'person-sven': 'Aanwezig',
        'person-anke': 'Aanwezig',
        'person-lars': 'Twijfel'
      }
    },
    {
      id: 'cal-2',
      title: 'Tactisch Overleg & Videoroom',
      type: 'Vergadering',
      date: '2026-07-24',
      time: '19:30 - 21:00',
      location: 'Kardinge',
      description: 'Doornemen van de wedstrijdstatistieken en tactische patronen van de tegenstanders. Drankjes en hapjes inbegrepen.',
      rsvps: {
        'person-michiel': 'Aanwezig',
        'person-sven': 'Afwezig',
        'person-danny': 'Aanwezig'
      }
    },
    {
      id: 'cal-3',
      title: 'Groningen Summer Cup - Amateurs',
      type: 'Toernooi',
      date: '2026-08-01',
      time: '09:00 - 18:00',
      location: 'Kardinge',
      description: 'Het leukste amateurtoernooi van het noorden met teams uit Emmen, Heerenveen, Leeuwarden en Groningen. Be there!',
      rsvps: {}
    }
  ],
  rulesCMS: `<h3><strong>1. Algemene Bepalingen &amp; Spirit of the Game</strong></h3>
<p>De Groningen House League (GHL) is opgericht om ijshockeyers van alle niveaus een veilige, sportieve en competitieve omgeving te bieden. Fair play en respect voor medespelers, scheidsrechters en vrijwilligers staan te allen tijde centraal. Onsportief gedrag wordt streng gesanctioneerd.</p>

<h3><strong>2. Wedstrijdduur &amp; Speelformaat</strong></h3>
<ul>
  <li>Een reguliere wedstrijd bestaat uit <strong>3 periodes van 20 minuten</strong> (doorlopende tijd).</li>
  <li>De laatste 2 minuten van de 3e periode wordt 'zuivere speeltijd' gehanteerd indien het doelsaldo 2 of minder is.</li>
  <li>Bij gelijke stand volgt direct een <strong>Shootout</strong> van 3 rondes per team.</li>
</ul>

<h3><strong>3. Uitrusting &amp; Veiligheid</strong></h3>
<p>Iedere speler is verplicht om een volledige en goedgekeurde ijshockeyuitrusting te dragen, inclusief een gecertificeerde helm (met vizier of cage) en een nekbeschermer. Zonder nekbeschermer is deelname aan wedstrijden of trainingen ten strengste verboden.</p>

<h3><strong>4. Strafbepalingen &amp; Schorsingen</strong></h3>
<p>Kleine straffen (Minor penalties) duren <strong>2 minuten</strong>. Grote straffen (Major penalties) duren <strong>5 minuten</strong> en kunnen leiden tot een automatische uitsluiting voor de rest van de wedstrijd (Game Misconduct). Bij een vechtpartij volgt een schorsing van minimaal 2 wedstrijden.</p>

<h3><strong>5. Leenspelers &amp; Spelerspool</strong></h3>
<p>Teams die door blessures of afwezigheid minder dan 10 veldspelers op het wedstrijdformulier kunnen zetten, mogen uitsluitend gebruikmaken van spelers uit de officiële GHL Spelerspool (Leenspelers). Dit dient uiterlijk 24 uur voor de wedstrijd te worden goedgekeurd door de League Officer.</p>`,
  draftSession: {
    id: 'draft-2026',
    status: 'NotStarted',
    currentRound: 1,
    currentPickIndex: 0,
    pickOrder: ['team-1', 'team-2', 'team-3', 'team-4'],
    draftedPlayers: []
  }
};
