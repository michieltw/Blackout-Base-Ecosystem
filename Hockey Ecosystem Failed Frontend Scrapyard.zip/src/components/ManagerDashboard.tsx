import React, { useState } from 'react';
import { AppDatabase, Team, Person, Equipment } from '../types';
import { updateTeamDetails, movePlayerToTeam, removePlayerFromTeam, addEquipment, updateEquipment, deleteEquipment } from '../services';
import { Shield, Settings, Sliders, Users, Plus, Wrench, Trash2, ArrowRightLeft, Award } from 'lucide-react';
import { TeamLogo } from './TeamLogo';

interface ManagerDashboardProps {
  db: AppDatabase;
  onUpdateDb: (updatedDb: AppDatabase) => void;
}

export const ManagerDashboard: React.FC<ManagerDashboardProps> = ({ db, onUpdateDb}) => {
  // Find which team this manager manages
  // A manager can be matched by personId or directly if they are a Multi-League Officer they can choose any team to manage!
  const isMultiLeague = db.currentUser.systemRole === 'MultiLeagueOfficer';
  const managerPersonId = db.currentUser.personId;
  const managedTeam = db.teams.find(t => t.managerId === managerPersonId);

  const [selectedTeamId, setSelectedTeamId] = useState<string>(
    managedTeam?.id || (db.teams.length > 0 ? db.teams[0].id : '')
  );

  // Active team to manage
  const team = db.teams.find(t => t.id === selectedTeamId);
  
  // Tactical State Form
  const [style, setStyle] = useState<Team['tactics']['style']>(team?.tactics.style || 'Neutraal');
  const [powerplayFocus, setPowerplayFocus] = useState<Team['tactics']['powerplayFocus']>(team?.tactics.powerplayFocus || 'Techniek');
  const [aggression, setAggression] = useState<number>(team?.tactics.aggression || 50);
  const [isSavingTactics, setIsSavingTactics] = useState(false);

  // New Equipment state
  const [eqPlayerId, setEqPlayerId] = useState<string>('');
  const [eqBrand, setEqBrand] = useState('Bauer');
  const [eqModel, setEqModel] = useState('Vapor Flylite');
  const [eqFlex, setEqFlex] = useState(82);
  const [eqCurve, setEqCurve] = useState('P92');

  // Trigger state sync when selected team changes
  React.useEffect(() => {
    if (team) {
      setStyle(team.tactics.style);
      setPowerplayFocus(team.tactics.powerplayFocus);
      setAggression(team.tactics.aggression);
    }
  }, [selectedTeamId, team]);

  if (!isMultiLeague && db.currentUser.systemRole !== 'Manager') {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center max-w-2xl mx-auto space-y-4" id="manager-no-access">
<h2 className="text-lg font-bold text-slate-200">Toegang Geweigerd</h2>
        <p className="text-slate-400 text-xs">
          Je hebt momenteel de rol <strong>{db.currentUser.systemRole}</strong>. Alleen teammanagers hebben toegang tot de teammanager-omgeving.
        </p>
        <p className="text-xs text-slate-900">
          Tip: Gebruik de <strong>Simuleer Gebruikersrol</strong> dropdown in de rechterbovenhoek om te wisselen naar <strong>Sven van den Broek</strong> of <strong>Michiel Waalboer</strong>!
        </p>
      </div>
    );
  }

  if (!team) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center" id="manager-no-team">
<p className="text-slate-400 text-xs">Er zijn geen teams beschikbaar om te beheren.</p>
      </div>
    );
  }

  // Get players belonging to this team
  const teamPlayers = db.persons.filter(
    p => p.roles.includes('Player') && team.playerIds.includes(p.id)
  );

  // Get players in the pools to recruit
  const poolPlayers = db.persons.filter(
    p => p.roles.includes('Player') && (p.playerPool === 'Leenspelers' || p.playerPool === 'Vrije Agenten')
  );

  const handleSaveTactics = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingTactics(true);
    const updated = updateTeamDetails(team.id, {
      tactics: {
        style,
        powerplayFocus,
        aggression
      }
    });
    onUpdateDb(updated);
    setTimeout(() => setIsSavingTactics(false), 500);
  };

  const handleReleasePlayer = (playerId: string) => {
    // Release player to the Leenspelers pool
    const updated = movePlayerToTeam(playerId, null, 'Leenspelers');
    onUpdateDb(updated);
  };

  const handleRecruitPlayer = (playerId: string) => {
    const updated = movePlayerToTeam(playerId, team.id, 'None');
    onUpdateDb(updated);
  };

  const handleAddStick = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eqPlayerId) return;

    const updated = addEquipment(eqPlayerId, {
      type: 'stick',
      brand: eqBrand,
      model: eqModel,
      specifications: {
        flex: eqFlex,
        curve: eqCurve
      },
      condition: 100
    });
    onUpdateDb(updated);
    // Reset form
    setEqModel('');
  };

  const handleRepairStick = (playerId: string, eqId: string) => {
    const updated = updateEquipment(playerId, eqId, { condition: 100 });
    onUpdateDb(updated);
  };

  const handleDeleteStick = (playerId: string, eqId: string) => {
    const updated = deleteEquipment(playerId, eqId);
    onUpdateDb(updated);
  };

  return (
    
      <div className="space-y-6" id="manager-view">{/* Team Selection Header for Multi-League */}
      <div className="bg-white border border-slate-200 p-5 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
<div>
          <div className="flex items-center space-x-2.5">
<TeamLogo logo={team.logo} name={team.name} size="sm" className="border border-slate-200" />
            <h2 className="text-lg font-extrabold text-slate-900">{team.name} beheren</h2>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Locatie: <span className="font-bold text-slate-700">{db.association?.locations?.[0]?.name || team.stadium || 'Kardinge'}</span> ({team.city})
          </p>
        </div>

        {isMultiLeague && (
          <div className="flex items-center space-x-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
<span className="text-xs text-xsurple-600 font-sans font-bold uppercase tracking-wider">Multi-League:</span>
            <select
              value={selectedTeamId}
              onChange={(e) => setSelectedTeamId(e.target.value)}
              className="bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 font-bold focus:outline-none focus:border-slate-200 transition-all shadow-sm cursor-pointer">{db.teams.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.city})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">{/* Tactics Panel */}
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm h-fit">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100 flex items-center space-x-2">
<Sliders className="w-5 h-5 text-slate-900" />
            <h3 className="font-bold text-sm text-slate-800 font-sans">Tactische Instellingen</h3>
          </div>

          <form onSubmit={handleSaveTactics} className="p-5 space-y-5 bg-white">
<div>
              <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-2">Algemene Speelstijl</label>
              <div className="grid grid-cols-3 gap-2">{(['Aanvallend', 'Neutraal', 'Verdedigend'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
onClick={() => setStyle(s)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      style === s
                        ? 'bg-slate-100 border-slate-200 text-slate-900 shadow-sm'
                        : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-400 mt-1.5">
                Speelstijl beïnvloedt de simulatiekans en aanvalsfrequentie.
              </p>
            </div>

            <div>
              <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-2">Powerplay Focus</label>
              <div className="grid grid-cols-3 gap-2">{(['Fysiek', 'Snelheid', 'Techniek'] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
onClick={() => setPowerplayFocus(f)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      powerplayFocus === f
                        ? 'bg-slate-100 border-slate-200 text-slate-900 shadow-sm'
                        : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
<label className="text-xs text-slate-500 font-bold uppercase tracking-wider">Team Agressie</label>
                <span className="text-xs font-mono font-bold text-slate-900">{aggression}%</span>
              </div>
              <input
                type="range"
min="10"
                max="100"
                value={aggression}
                onChange={(e) => setAggression(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-100 h-1.5 rounded-lg appearance-none cursor-pointer"
/>
              <p className="text-xs text-slate-400 mt-1">
                Let op: Hogere agressie verhoogt de kans op doelpunten, maar zorgt ook voor meer strafminuten!
              </p>
            </div>

            <button
              id="save-tactics-btn"
              type="submit"
disabled={isSavingTactics}
              className="w-full bg-slate-900 hover:bg-slate-950 text-white text-xs font-bold py-3 px-4 rounded-xl transition shadow-lg shadow-amber-100 flex items-center justify-center space-x-1 cursor-pointer">
<Settings className="w-4 h-4 animate-spin-slow" />
              <span>{isSavingTactics ? 'Opslaan...' : 'Tactiek Opslaan'}</span>
            </button>
          </form>
        </div>

        {/* Players & Equipment Management */}
        <div className="lg:col-span-2 space-y-6">{/* Roster list */}
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100 flex justify-between items-center">
<div className="flex items-center space-x-2">
<Users className="w-5 h-5 text-slate-900" />
                <h3 className="font-bold text-sm text-slate-800">Teamselectie ({teamPlayers.length} Spelers)</h3>
              </div>
              <span className="text-xs bg-white border border-slate-200 px-2.5 py-1 rounded-full font-mono text-slate-500">Roster</span>
            </div>

            <div className="divide-y divide-slate-100 bg-white">{teamPlayers.map((player) => {
                const stick = player.equipment?.find(e => e.type === 'stick');
                return (
                  <div key={player.id} className="p-4 hover:bg-slate-50/50 transition flex flex-col md:flex-row md:items-center justify-between gap-4">
<div className="flex items-center space-x-3 min-w-0">
<img
                        src={player.avatar}
                        alt={player.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 referrer-no-referrer"
referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
<div className="flex items-center space-x-1.5">
<p className="text-sm font-bold text-slate-900 truncate">{player.name}</p>
                          <span className="text-[10px] bg-slate-100 text-slate-900 px-1.5 py-0.5 rounded border border-slate-200 font-bold">
                            Rating: {player.stats?.rating}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 italic truncate max-w-sm mt-0.5">{player.bio}</p>
                        
                        {/* Equipment Status Line */}
                        <div className="flex items-center space-x-3 mt-1.5">{stick ? (
                            <div className="flex flex-wrap items-center gap-1.5">
<span className="text-xs bg-slate-50 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200 font-mono">
                                Stick: {stick.brand} {stick.model} (Flex {stick.specifications.flex})
                              </span>
                              <span className={`text-xs font-mono font-bold px-1 rounded ${
                                stick.condition > 70 ? 'text-slate-900' : stick.condition > 40 ? 'text-slate-900' : 'text-slate-900'
                              }`}>
                                Conditie: {stick.condition}%
                              </span>
                              {stick.condition < 100 && (
                                <button
                                  onClick={() => handleRepairStick(player.id, stick.id)}
                                  className="text-xs text-slate-900 hover:text-white hover:bg-slate-100 flex items-center space-x-0.5 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 cursor-pointer transition-all"
title="Repareer stick naar 100% conditie">
<Wrench className="w-3 h-3" />
                                  <span>Repareer</span>
                                </button>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs text-slate-900 italic font-semibold">Geen stick toegewezen!</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between md:justify-end space-x-4 shrink-0">{/* Stats Overview */}
                      <div className="text-right">
<div className="text-xs text-slate-500 font-mono">
<span className="font-bold text-slate-800">{player.stats?.goals}</span> G / <span className="font-bold text-slate-800">{player.stats?.assists}</span> A
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono">Points: {player.stats?.points} | PIM: {player.stats?.penaltyMinutes}</p>
                      </div>

                      {/* Remove/Release button */}
                      <button
                        onClick={() => handleReleasePlayer(player.id)}
                        className="text-xs text-slate-900 hover:text-white hover:bg-slate-100 bg-slate-100 border border-slate-200 p-2 rounded-xl transition cursor-pointer font-bold"
title="Verplaats speler naar de leenspelers pool">
                        De-selecteer / Leen uit
                      </button>
                    </div>
                  </div>
                );
              })}
              {teamPlayers.length === 0 && (
                <div className="p-8 text-center text-slate-400 font-sans">
                  Er zijn geen spelers in deze selectie. Trek spelers aan uit de spelerpools hieronder!
                </div>
              )}
            </div>
          </div>

          {/* Recruit from Pools Panel */}
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100 flex items-center justify-between">
<div className="flex items-center space-x-2">
<ArrowRightLeft className="w-5 h-5 text-slate-900" />
                <h3 className="font-bold text-sm text-slate-800">Spelers Contracteren uit de Spelerpool</h3>
              </div>
              <span className="text-xs bg-slate-100 text-slate-900 border border-slate-200 px-2.5 py-1 rounded-full font-mono font-bold">Transfers</span>
            </div>

            <div className="divide-y divide-slate-100 bg-white max-h-[320px] overflow-y-auto hide-scrollbar hide-scrollbar">{poolPlayers.map((player) => (
                <div key={player.id} className="p-3 hover:bg-slate-50/50 transition flex items-center justify-between">
<div className="flex items-center space-x-3">
<img
                      src={player.avatar}
                      alt={player.name}
                      className="w-8 h-8 rounded-full border border-slate-200 object-cover referrer-no-referrer"
referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-800">{player.name}</p>
                      <div className="flex items-center space-x-2 mt-0.5">
<span className="text-[10px] bg-slate-50 text-slate-500 px-1 border border-slate-200 rounded font-mono">
                          Rating: {player.stats?.rating}
                        </span>
                        <span className={`text-[10px] px-1 rounded font-semibold ${
                          player.playerPool === 'Leenspelers' ? 'bg-slate-100 text-slate-900' : 'bg-slate-100 text-xsurple-600'
                        }`}>
                          {player.playerPool}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleRecruitPlayer(player.id)}
                    className="text-xs bg-slate-900 hover:bg-slate-950 text-white font-bold py-1.5 px-3.5 rounded-xl transition shadow-md shadow-emerald-100 cursor-pointer">
                    Contracteer Speler
                  </button>
                </div>
              ))}
              {poolPlayers.length === 0 && (
                <p className="p-6 text-center text-slate-400 text-xs">Er zijn momenteel geen vrije spelers of leenspelers in de pool.</p>
              )}
            </div>
          </div>

          {/* Quick Equipment Creator/Assigner */}
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm p-5">
<h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center space-x-1.5 pb-2 border-b border-slate-100">
<span>Nieuwe Stick Toewijzen</span>
            </h4>
            
            <form onSubmit={handleAddStick} className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
<div className="md:col-span-1">
<label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Kies Speler</label>
                <select
                  value={eqPlayerId}
                  onChange={(e) => setEqPlayerId(e.target.value)}
                  className="w-full bg-white text-slate-850 text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-all cursor-pointer"
required
                >
                  <option value="">-- Kies --</option>
                  {teamPlayers.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-1">
<label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Merk</label>
                <select
                  value={eqBrand}
                  onChange={(e) => setEqBrand(e.target.value)}
                  className="w-full bg-white text-slate-850 text-xs border border-slate-200 rounded-lg p-2 cursor-pointer">
<option value="Bauer">Bauer</option>
                  <option value="CCM">CCM</option>
                  <option value="Warrior">Warrior</option>
                  <option value="Sherwood">Sherwood</option>
                </select>
              </div>

              <div className="md:col-span-1">
<label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Model Stick</label>
                <input
                  type="text"
placeholder="bijv. Nexus Sync"
                  value={eqModel}
                  onChange={(e) => setEqModel(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-all"
required
                />
              </div>

              <div className="md:col-span-1">
<label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Stick Flex</label>
                <input
                  type="number"
min="60"
                  max="110"
                  value={eqFlex}
                  onChange={(e) => setEqFlex(Number(e.target.value))}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 focus:outline-none"
required
                />
              </div>

              <div className="md:col-span-1">
<button
                  type="submit"
className="w-full bg-slate-900 hover:bg-slate-950 text-white font-bold text-xs py-2.5 px-3 rounded-xl transition shadow-md shadow-blue-100 cursor-pointer">
                  Toewijzen
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    
  );
};
