import React, { useState } from 'react';
import { AppDatabase, League, Person } from '../types';
import { createLeague, createPerson, movePlayerToTeam } from '../services';
import { Layers, PlusCircle, Users, Award, Shield, FileText } from 'lucide-react';

interface MultiLeagueOfficerDashboardProps {
  db: AppDatabase;
  onUpdateDb: (updatedDb: AppDatabase) => void;
}

export const MultiLeagueOfficerDashboard: React.FC<MultiLeagueOfficerDashboardProps> = ({ db, onUpdateDb}) => {
  // New League Form
  const [leagueName, setLeagueName] = useState('');
  const [leagueSeason, setLeagueSeason] = useState('2026-2027');
  const [leagueRegion, setLeagueRegion] = useState('Benelux');
  const [leagueOfficerId, setLeagueOfficerId] = useState('');
  const [isCreatingLeague, setIsCreatingLeague] = useState(false);

  // New Player Form
  const [playerName, setPlayerName] = useState('');
  const [playerBirthdate, setPlayerBirthdate] = useState('2000-01-01');
  const [playerNationality, setPlayerNationality] = useState('Nederlands');
  const [playerBio, setPlayerBio] = useState('');
  const [playerRating, setPlayerRating] = useState(78);
  const [playerPool, setPlayerPool] = useState<'Leenspelers' | 'Vrije Agenten'>('Leenspelers');
  const [isCreatingPlayer, setIsCreatingPlayer] = useState(false);

  if (db.currentUser.systemRole !== 'MultiLeagueOfficer') {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center max-w-2xl mx-auto space-y-4 shadow-sm" id="multi-no-access">
<h2 className="text-lg font-bold text-slate-800">Toegang Geweigerd</h2>
        <p className="text-slate-500 text-xs">
          Je hebt de systeemrol <strong>{db.currentUser.systemRole}</strong>. Alleen de Multi-League Officer heeft toegang tot dit globale bestuurspaneel.
        </p>
        <p className="text-xs text-slate-900 font-semibold">
          Tip: Gebruik de <strong>Simuleer Gebruikersrol</strong> dropdown rechtsboven om te wisselen naar de <strong>Multi-League Officer (Robert)</strong>!
        </p>
      </div>
    );
  }

  const handleCreateLeague = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leagueName) return;

    setIsCreatingLeague(true);
    const updated = createLeague({
      name: leagueName,
      season: leagueSeason,
      region: leagueRegion,
      officerId: leagueOfficerId || null,
      teamIds: []
    });
    onUpdateDb(updated);

    // Reset Form
    setLeagueName('');
    setIsCreatingLeague(false);
  };

  const handleCreatePlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName) return;

    setIsCreatingPlayer(true);
    const updated = createPerson({
      name: playerName,
      avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_player_male.png?v=1784405789',
      birthdate: playerBirthdate,
      nationality: playerNationality,
      bio: playerBio || 'Veelbelovende ijshockeyer klaar voor actie.',
      roles: ['Player'],
      playerPool,
      teamIds: [],
      equipment: [
        {
          id: `eq-gen-${Date.now()}`,
          type: 'stick',
          brand: 'Bauer',
          model: 'Vapor Hyperlite',
          specifications: { flex: 82, curve: 'P92' },
          condition: 100
        }
      ],
      stats: {
        gamesPlayed: 0,
        goals: 0,
        assists: 0,
        points: 0,
        penaltyMinutes: 0,
        rating: playerRating,
        speed: playerRating + 2,
        shooting: playerRating - 2,
        passing: playerRating,
        defense: playerRating - 5,
        physical: playerRating
      }
    });
    onUpdateDb(updated);

    // Reset Form
    setPlayerName('');
    setPlayerBio('');
    setPlayerRating(78);
    setIsCreatingPlayer(false);
  };

  const handleMovePool = (playerId: string, pool: 'Leenspelers' | 'Vrije Agenten') => {
    const updated = movePlayerToTeam(playerId, null, pool);
    onUpdateDb(updated);
  };

  // List of all persons who could be assigned as League Officer
  const potentialOfficers = db.persons;

  // Filter pool players to display centrally
  const poolPlayers = db.persons.filter(
    p => p.roles.includes('Player') && (p.playerPool === 'Leenspelers' || p.playerPool === 'Vrije Agenten')
  );

  return (
    
      <div className="space-y-6" id="multi-league-officer-view">
<div className="bg-white border border-slate-200 p-5 rounded-3xl shadow-sm">
<div className="flex items-center space-x-2">
<Layers className="w-6 h-6 text-xsurple-600" />
          <h2 className="text-lg font-bold text-slate-800">Multi-League Bestuurskamer</h2>
        </div>
        <p className="text-xs text-slate-500 mt-1">
          Als Multi-League Officer heeft u de supervisie over alle competities, de spelerpools en kunt u direct de autorisatielijnen bepalen.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">{/* Create Competitions */}
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm p-5">
<h3 className="font-bold text-sm text-slate-800 mb-4 flex items-center space-x-2 pb-2 border-b border-slate-100">
<PlusCircle className="w-5 h-5 text-xsurple-600" />
            <span>Nieuwe Competitie Oprichtingsakte</span>
          </h3>

          <form onSubmit={handleCreateLeague} className="space-y-4">
<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
<div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Competitienaam</label>
                <input
                  type="text"
placeholder="bijv. Eredivisie Cup of Divisie 1"
                  value={leagueName}
                  onChange={(e) => setLeagueName(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:ring-1 focus:ring-purple-500 focus:outline-none transition-all"
required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Seizoen</label>
                <input
                  type="text"
placeholder="bijv. 2026-2027"
                  value={leagueSeason}
                  onChange={(e) => setLeagueSeason(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:ring-1 focus:ring-purple-500 focus:outline-none transition-all"
required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
<div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Regio</label>
                <input
                  type="text"
placeholder="bijv. Benelux, Nederland"
                  value={leagueRegion}
                  onChange={(e) => setLeagueRegion(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-purple-500"
required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Toewijzen League Officer</label>
                <select
                  value={leagueOfficerId}
                  onChange={(e) => setLeagueOfficerId(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:ring-1 focus:ring-purple-500 focus:outline-none cursor-pointer">
<option value="">-- Geen officer (of later toewijzen) --</option>
                  {potentialOfficers.map(o => (
                    <option key={o.id} value={o.id}>{o.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <button
              type="submit"
disabled={isCreatingLeague}
              className="w-full bg-slate-900 hover:bg-slate-950 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow-md shadow-purple-100 cursor-pointer">{isCreatingLeague ? 'Bezig met aanmaken...' : 'Competitie Toevoegen'}
            </button>
          </form>
        </div>

        {/* Global Player Pool Creator */}
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm p-5">
<h3 className="font-bold text-sm text-slate-800 mb-4 flex items-center space-x-2 pb-2 border-b border-slate-100">
<Users className="w-5 h-5 text-xsurple-600" />
            <span>Nieuwe Speler Genereren & in Pool Plaatsen</span>
          </h3>

          <form onSubmit={handleCreatePlayer} className="space-y-4">
<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
<div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Volledige Naam</label>
                <input
                  type="text"
placeholder="Volledige naam"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:ring-1 focus:ring-purple-500 focus:outline-none transition-all"
required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Geboortedatum</label>
                <input
                  type="date"
value={playerBirthdate}
                  onChange={(e) => setPlayerBirthdate(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
<div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Nationaliteit</label>
                <input
                  type="text"
value={playerNationality}
                  onChange={(e) => setPlayerNationality(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Algemene Rating (60-95)</label>
                <input
                  type="number"
min="60"
                  max="95"
                  value={playerRating}
                  onChange={(e) => setPlayerRating(Number(e.target.value))}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Kies Spelerpool</label>
                <select
                  value={playerPool}
                  onChange={(e) => setPlayerPool(e.target.value as any)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 cursor-pointer">
<option value="Leenspelers">Leenspelers</option>
                  <option value="Vrije Agenten">Vrije Agenten</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Korte Bio / Speelstijl</label>
              <textarea
                rows={2}
                placeholder="Geef hier specifieke ijshockey kwaliteiten aan..."
                value={playerBio}
                onChange={(e) => setPlayerBio(e.target.value)}
                className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
/>
            </div>

            <button
              type="submit"
disabled={isCreatingPlayer}
              className="w-full bg-slate-900 hover:bg-slate-950 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow-md shadow-emerald-100 cursor-pointer">{isCreatingPlayer ? 'Bezig...' : 'Genereer & Plaats in Pool'}
            </button>
          </form>
        </div>
      </div>

      {/* Pools Central Control */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100 flex justify-between items-center">
<h3 className="font-bold text-sm text-slate-800 flex items-center space-x-1.5">
<span>Centraal Spelerpools Toezicht ({poolPlayers.length} Spelers)</span>
          </h3>
          <span className="text-xs bg-slate-100 text-xsurple-700 border border-slate-200 px-2.5 py-1 rounded-full font-mono font-bold">Globale Pools</span>
        </div>

        <div className="overflow-x-auto hide-scrollbar bg-white">
<table className="w-full text-left text-xs">
<thead className="bg-slate-50 text-slate-500 font-sans font-bold text-xs uppercase tracking-wider border-b border-slate-100">
<tr>
                <th className="py-3 px-4">Speler</th>
                <th className="py-3 px-4">Geboortedatum</th>
                <th className="py-3 px-4">Nationaliteit</th>
                <th className="py-3 px-4 text-center">Rating</th>
                <th className="py-3 px-4">Huidige Spelerpool</th>
                <th className="py-3 px-4 text-right">Actie</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">{poolPlayers.map((player) => (
                <tr key={player.id} className="hover:bg-slate-50/50 transition">
<td className="py-3 px-4 flex items-center space-x-3">
<img
                      src={player.avatar}
                      alt={player.name}
                      className="w-8 h-8 rounded-full border border-slate-200 referrer-no-referrer object-cover"
referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="text-slate-800 font-bold">{player.name}</p>
                      <p className="text-xs text-slate-400 font-sans truncate max-w-xs">{player.bio}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-500 font-medium">{player.birthdate}</td>
                  <td className="py-3 px-4 font-semibold text-slate-600">{player.nationality}</td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-slate-900">{player.stats?.rating}</td>
                  <td className="py-3 px-4">
<span className={`text-xs px-2 py-0.5 rounded font-bold ${
                      player.playerPool === 'Leenspelers' ? 'bg-slate-100 text-slate-900 border border-slate-200' : 'bg-slate-100 text-xsurple-600 border border-slate-200'
                    }`}>
                      {player.playerPool}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">{player.playerPool === 'Leenspelers' ? (
                      <button
                        onClick={() => handleMovePool(player.id, 'Vrije Agenten')}
                        className="text-xs bg-slate-100 hover:bg-slate-100 hover:text-white text-xsurple-600 border border-slate-200 px-2.5 py-1.5 rounded-xl font-bold transition cursor-pointer">
                        Maak Vrije Agent
                      </button>
                    ) : (
                      <button
                        onClick={() => handleMovePool(player.id, 'Leenspelers')}
                        className="text-xs bg-slate-100 hover:bg-slate-100 hover:text-white text-slate-900 border border-slate-200 px-2.5 py-1.5 rounded-xl font-bold transition cursor-pointer">
                        Maak Leenspeler
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {poolPlayers.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-400 font-sans">
                    Er zijn momenteel geen spelers geregistreerd in de pools. Maak er hierboven een aan!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
  );
};
