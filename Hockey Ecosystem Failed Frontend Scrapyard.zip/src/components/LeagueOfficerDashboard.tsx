import React, { useState } from 'react';
import { AppDatabase, League, Team, Match } from '../types';
import { updateLeagueDetails, toggleTeamInLeague, scheduleMatch } from '../services';
import { Trophy, Calendar, Plus, Info, Shield, PlusCircle, Check } from 'lucide-react';
import { TeamLogo } from './TeamLogo';

interface LeagueOfficerDashboardProps {
  db: AppDatabase;
  onUpdateDb: (updatedDb: AppDatabase) => void;
}

export const LeagueOfficerDashboard: React.FC<LeagueOfficerDashboardProps> = ({ db, onUpdateDb}) => {
  const isMultiLeague = db.currentUser.systemRole === 'MultiLeagueOfficer';
  const officerPersonId = db.currentUser.personId;

  // Find league managed by this officer, or allow selecting any if Multi-League Officer
  const managedLeagues = db.leagues.filter(l => l.officerId === officerPersonId);
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>(
    managedLeagues[0]?.id || (db.leagues.length > 0 ? db.leagues[0].id : '')
  );

  const league = db.leagues.find(l => l.id === selectedLeagueId);

  // New Match state
  const [homeTeamId, setHomeTeamId] = useState('');
  const [awayTeamId, setAwayTeamId] = useState('');
  const [matchDate, setMatchDate] = useState('2026-07-28');
  const [isScheduling, setIsScheduling] = useState(false);

  if (!isMultiLeague && db.currentUser.systemRole !== 'LeagueOfficer') {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center max-w-2xl mx-auto space-y-4 shadow-sm" id="league-no-access">
<h2 className="text-lg font-bold text-slate-800">Toegang Geweigerd</h2>
        <p className="text-slate-500 text-xs">
          Je hebt de systeemrol <strong>{db.currentUser.systemRole}</strong>. Alleen de League Officer of de Multi-League Officer heeft toegang tot dit beheerpaneel.
        </p>
        <p className="text-xs text-slate-900 font-semibold">
          Tip: Gebruik de <strong>Simuleer Gebruikersrol</strong> dropdown rechtsboven om te wisselen naar <strong>Anke de Vries</strong> of de <strong>Multi-League Officer</strong>!
        </p>
      </div>
    );
  }

  if (!league) {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center shadow-sm" id="league-no-league">
<p className="text-slate-500 text-xs">Er zijn geen competities beschikbaar om te beheren.</p>
      </div>
    );
  }

  // Get teams in this league
  const leagueTeams = db.teams.filter(t => league.teamIds.includes(t.id));
  
  // Teams not in this league
  const otherTeams = db.teams.filter(t => !league.teamIds.includes(t.id));

  // Get matches for this league
  const matches = db.matches.filter(m => m.leagueId === league.id);
  const scheduledMatches = matches.filter(m => m.status === 'Scheduled' || m.status === 'Gepland');
  const playedMatches = matches.filter(m => m.status === 'Played' || m.status === 'Afgerond' || m.status === 'Verwerkt').reverse();

  const handleToggleTeam = (teamId: string) => {
    const updated = toggleTeamInLeague(league.id, teamId);
    onUpdateDb(updated);
  };

  const handleCreateMatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!homeTeamId || !awayTeamId || homeTeamId === awayTeamId) {
      alert('Kies twee verschillende teams!');
      return;
    }

    setIsScheduling(true);
    const updated = scheduleMatch({
      leagueId: league.id,
      homeTeamId,
      awayTeamId,
      date: matchDate
    });
    onUpdateDb(updated);
    
    // Reset fields
    setHomeTeamId('');
    setAwayTeamId('');
    setIsScheduling(false);
  };

  return (
    
      <div className="space-y-6" id="league-officer-view">{/* Selector and Header */}
      <div className="bg-white border border-slate-200 p-5 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
<div>
          <div className="flex items-center space-x-2">
<Trophy className="w-6 h-6 text-slate-900" />
            <h2 className="text-lg font-bold text-slate-800">Competitiebeheer: {league.name}</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Seizoen: <span className="font-bold text-slate-700">{league.season}</span> | Region: <span className="font-bold text-slate-700">{league.region}</span>
          </p>
        </div>

        {/* Let them switch between multiple managed leagues */}
        {(isMultiLeague || managedLeagues.length > 1) && (
          <div className="flex items-center space-x-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
<span className="text-xs text-slate-900 font-sans font-bold uppercase tracking-wider">Selecteer Competitie:</span>
            <select
              value={selectedLeagueId}
              onChange={(e) => setSelectedLeagueId(e.target.value)}
              className="bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 font-bold focus:outline-none focus:border-slate-200 transition-all shadow-sm cursor-pointer">{isMultiLeague
                ? db.leagues.map(l => (
                    <option key={l.id} value={l.id}>{l.name} ({l.season})</option>
                  ))
                : managedLeagues.map(l => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))
              }
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">{/* League Teams Enrollment */}
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm h-fit">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100">
<h3 className="font-bold text-sm text-slate-800 flex items-center space-x-1.5">
<span>Deelnemende Teams Beheren</span>
            </h3>
          </div>

          <div className="p-5 space-y-4">
<div>
              <h4 className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-2">Ingeschreven ({leagueTeams.length})</h4>
              <div className="space-y-1.5">{leagueTeams.map(t => (
                  <div key={t.id} className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl border border-slate-100 shadow-sm">
<div className="flex items-center space-x-2">
<TeamLogo logo={t.logo} name={t.name} size="xs" />
                      <span className="text-xs font-bold text-slate-800">{t.name}</span>
                    </div>
                    <button
                      onClick={() => handleToggleTeam(t.id)}
                      className="text-xs bg-slate-100 hover:bg-slate-100 hover:text-white text-slate-900 border border-slate-200 px-2.5 py-1.5 rounded-xl font-bold transition cursor-pointer">
                      Uitschrijven
                    </button>
                  </div>
                ))}
                {leagueTeams.length === 0 && (
                  <p className="text-xs text-slate-400 italic">Nog geen teams ingeschreven.</p>
                )}
              </div>
            </div>

            <div>
              <h4 className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-2">Andere Teams Uit Database ({otherTeams.length})</h4>
              <div className="space-y-1.5">{otherTeams.map(t => (
                  <div key={t.id} className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-100 shadow-sm">
<div className="flex items-center space-x-2">
<TeamLogo logo={t.logo} name={t.name} size="xs" />
                      <span className="text-xs font-bold text-slate-700">{t.name}</span>
                    </div>
                    <button
                      onClick={() => handleToggleTeam(t.id)}
                      className="text-xs bg-slate-100 hover:bg-slate-100 hover:text-white text-slate-900 border border-slate-200 px-2.5 py-1.5 rounded-xl font-bold transition flex items-center space-x-1 cursor-pointer">
<Plus className="w-3 h-3" />
                      <span>Inschrijven</span>
                    </button>
                  </div>
                ))}
                {otherTeams.length === 0 && (
                  <p className="text-xs text-slate-400 italic">Geen externe teams beschikbaar.</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Match Scheduler & Interactive Simulator */}
        <div className="lg:col-span-2 space-y-6">{/* Create Match Schedule */}
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden p-5 shadow-sm">
<h3 className="font-bold text-sm text-slate-800 mb-4 flex items-center space-x-2 pb-2 border-b border-slate-100">
<Calendar className="w-5 h-5 text-slate-900" />
              <span>Nieuwe Wedstrijd Inplannen</span>
            </h3>

            <form onSubmit={handleCreateMatch} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
<div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Thuisteam</label>
                <select
                  value={homeTeamId}
                  onChange={(e) => setHomeTeamId(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-all cursor-pointer"
required
                >
                  <option value="">-- Kies --</option>
                  {leagueTeams.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Uitteam</label>
                <select
                  value={awayTeamId}
                  onChange={(e) => setAwayTeamId(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-all cursor-pointer"
required
                >
                  <option value="">-- Kies --</option>
                  {leagueTeams.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Datum</label>
                <input
                  type="date"
value={matchDate}
                  onChange={(e) => setMatchDate(e.target.value)}
                  className="w-full bg-white text-slate-800 text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-all cursor-pointer"
required
                />
              </div>

              <div>
                <button
                  type="submit"
disabled={isScheduling}
                  className="w-full bg-slate-900 hover:bg-slate-950 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition shadow-md shadow-blue-100 flex items-center justify-center space-x-1 cursor-pointer">
<PlusCircle className="w-4 h-4" />
                  <span>{isScheduling ? 'Plannen...' : 'Inplannen'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Scheduled Matches */}
          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
<div className="bg-slate-50/50 px-5 py-4 border-b border-slate-100 flex justify-between items-center">
<h3 className="font-bold text-sm text-slate-800 flex items-center space-x-1.5">
<span>Ingeplande Wedstrijden</span>
              </h3>
              <span className="text-xs bg-white border border-slate-200 text-slate-500 px-2.5 py-1 rounded-full font-mono font-bold">{scheduledMatches.length}</span>
            </div>

            <div className="divide-y divide-slate-100 max-h-[350px] overflow-y-auto hide-scrollbar bg-white">{scheduledMatches.map((match) => {
                const home = db.teams.find(t => t.id === match.homeTeamId);
                const away = db.teams.find(t => t.id === match.awayTeamId);
                return (
                  <div key={match.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-all">
<div className="min-w-0 flex-1">
<div className="flex items-center space-x-2">
<span className="text-xs text-slate-400 font-mono font-bold">{match.date}</span>
                        <span className="text-[10px] bg-slate-100 text-slate-900 border border-slate-200 px-1.5 py-0.5 rounded font-bold uppercase font-mono">Ingepland</span>
                      </div>
                      <div className="flex items-center space-x-4 mt-2">
<span className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
<TeamLogo logo={home?.logo} name={home?.name} size="xs" />
                          <span>{home?.name}</span>
                        </span>
                        <span className="text-xs font-bold font-mono text-slate-400 bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded">VS</span>
                        <span className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
<TeamLogo logo={away?.logo} name={away?.name} size="xs" />
                          <span>{away?.name}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
              {scheduledMatches.length === 0 && (
                <div className="p-8 text-center text-slate-400 text-xs">
                  Er zijn momenteel geen geplande wedstrijden. Gebruik het formulier hierboven om er een in te plannen!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
    
  );
};
