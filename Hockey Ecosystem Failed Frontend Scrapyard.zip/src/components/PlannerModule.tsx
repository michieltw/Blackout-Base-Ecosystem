import React, { useState } from 'react';
import { AppDatabase, CalendarEvent, Match, Season, SeasonPhase } from '../types';
import { 
  Calendar as CalendarIcon, 
  Clock as ClockIcon, 
  MapPin as MapPinIcon, 
  Search as SearchIcon, 
  Plus as PlusIcon, 
  Trash2 as TrashIcon, 
  CheckCircle as CheckCircleIcon, 
  Trophy as TrophyIcon, 
  Flag as FlagIcon, 
  Users as UsersIcon, 
  Activity as ActivityIcon, 
  Dumbbell as DumbbellIcon, 
  CalendarPlus as CalendarPlusIcon, 
  Sparkles as SparklesIcon, 
  X as XIcon, 
  FileText as FileTextIcon,
  Layers as LayersIcon,
  ShieldCheck as ShieldCheckIcon,
  HelpCircle,
  Info
} from 'lucide-react';
import { addCalendarEvents, deleteCalendarEvent, deleteMatch } from '../services';

interface PlannerModuleProps {
  db: AppDatabase;
  onUpdateDb: (db: AppDatabase) => void;
}

export type ActivityType = 'Seizoen' | 'Seizoensfase' | 'Games' | 'Tournooi' | 'Training' | 'Meeting' | 'Overige';

export default function PlannerModule({ db, onUpdateDb }: PlannerModuleProps) {
  // STAP 1: Geselecteerde activiteit type
  const [selectedType, setSelectedType] = useState<ActivityType | null>(null);

  // STAP 2: Vragen/Velden per activiteit type
  
  // Algemene Datum & Tijd
  const [startDatum, setStartDatum] = useState<string>(new Date().toISOString().split('T')[0]);
  const [hasEindDatum, setHasEindDatum] = useState<boolean>(false);
  const [eindDatum, setEindDatum] = useState<string>('');
  const [tussendatums, setTussendatums] = useState<string[]>([]);
  const [newTussendatumInput, setNewTussendatumInput] = useState<string>('');

  const [beginTijd, setBeginTijd] = useState<string>('19:30');
  const [eindTijd, setEindTijd] = useState<string>('21:00');
  const [tussentijden, setTussentijden] = useState<string[]>([]);
  const [newTussentijdInput, setNewTussentijdInput] = useState<string>('');

  const [locatie, setLocatie] = useState<string>(db.association?.locations?.[0]?.name || 'Kardinge');

  // Specifieke velden per type:
  // 1. SEIZOEN
  const [seizoenNaam, setSeizoenNaam] = useState<string>('');
  const [seizoenJaren, setSeizoenJaren] = useState<string>('2026-2027');
  const [selectedLeagueId, setSelectedLeagueId] = useState<string>(db.leagues[0]?.id || 'league-ghl');

  // 2. SEIZOENSFASE
  const [selectedSeasonId, setSelectedSeasonId] = useState<string>(db.seasons[0]?.id || '');
  const [faseType, setFaseType] = useState<'Pre-Season' | 'Regular Season' | 'Playoffs' | 'Tournament'>('Regular Season');

  // 3. GAMES (WEDSTRIJDEN)
  const [gameSeasonId, setGameSeasonId] = useState<string>(db.seasons[0]?.id || '');
  const [gamePhaseName, setGamePhaseName] = useState<string>('Regular Season');
  const [aantalGames, setAantalGames] = useState<number>(1);
  const [homeTeamIsTBD, setHomeTeamIsTBD] = useState<boolean>(false);
  const [homeTeamId, setHomeTeamId] = useState<string>(db.teams[0]?.id || '');
  const [awayTeamIsTBD, setAwayTeamIsTBD] = useState<boolean>(false);
  const [awayTeamId, setAwayTeamId] = useState<string>(db.teams[1]?.id || '');
  const [ruleset, setRuleset] = useState<string>('Standard House League Rules');
  const [speelrondeNaam, setSpeelrondeNaam] = useState<string>('Speelronde 1');

  // 4. OVERIGE OPTIES (Tournooi, Training, Meeting, Overige)
  const [linkedSeasonId, setLinkedSeasonId] = useState<string>(''); // Optioneel koppelen aan seizoen
  const [titel, setTitel] = useState<string>('');
  const [doelgroep, setDoelgroep] = useState<string>('Alle Teams');
  const [omschrijving, setOmschrijving] = useState<string>('');

  // Status/feedback
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Overzicht Filter state
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('Alle');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterDatum, setFilterDatum] = useState<string>('');

  // Datums toevoegen/verwijderen
  const handleAddTussendatum = () => {
    if (newTussendatumInput && !tussendatums.includes(newTussendatumInput)) {
      setTussendatums([...tussendatums, newTussendatumInput].sort());
      setNewTussendatumInput('');
    }
  };

  const handleRemoveTussendatum = (dateStr: string) => {
    setTussendatums(tussendatums.filter(d => d !== dateStr));
  };

  // Tijden toevoegen/verwijderen
  const handleAddTussentijd = () => {
    if (newTussentijdInput.trim() && !tussentijden.includes(newTussentijdInput.trim())) {
      setTussentijden([...tussentijden, newTussentijdInput.trim()]);
      setNewTussentijdInput('');
    }
  };

  const handleRemoveTussentijd = (timeStr: string) => {
    setTussentijden(tussentijden.filter(t => t !== timeStr));
  };

  // VERWERK EN OPSLAAN VAN HET FORMULIER
  const handleSubmitPlanning = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType) return;

    const defaultLoc = locatie || db.association?.locations?.[0]?.name || 'Kardinge';
    const timestamp = Date.now();
    let createdCount = 0;

    if (selectedType === 'Seizoen') {
      // 1. SEIZOEN
      const seasonName = seizoenNaam || `Seizoen ${seizoenJaren}`;
      const newSeason: Season = {
        id: `season-${timestamp}`,
        leagueId: selectedLeagueId,
        name: seasonName,
        years: seizoenJaren,
        startDate: startDatum,
        endDate: hasEindDatum && eindDatum ? eindDatum : `${new Date(startDatum).getFullYear() + 1}-04-30`,
        isActive: true,
        isCurrent: true
      };

      // Deactiveer eventuele vorige seizoenen als isCurrent
      db.seasons = (db.seasons || []).map(s => s.leagueId === selectedLeagueId ? { ...s, isCurrent: false } : s);
      db.seasons.push(newSeason);

      // Ook toevoegen aan centrale kalender
      const calEvt: CalendarEvent = {
        id: `evt-${timestamp}`,
        title: `Seizoen: ${seasonName}`,
        type: 'Seizoen',
        category: 'Seizoen',
        date: startDatum,
        endDate: hasEindDatum ? eindDatum : undefined,
        time: beginTijd,
        endTime: eindTijd,
        location: defaultLoc,
        description: `Start van ${seasonName} (${seizoenJaren}). Gepland van ${startDatum} tot ${eindDatum || 'einde seizoen'}.`,
        seasonId: newSeason.id,
        relatedLeagueId: selectedLeagueId,
        rsvps: {}
      };

      db.calendarEvents = [...(db.calendarEvents || []), calEvt];
      createdCount = 1;

    } else if (selectedType === 'Seizoensfase') {
      // 2. SEIZOENSFASE
      if (!selectedSeasonId) {
        alert('Selecteer a.u.b. een bestaand seizoen om deze fase aan te koppelen.');
        return;
      }

      const targetSeason = db.seasons.find(s => s.id === selectedSeasonId);
      const phaseId = `phase-${timestamp}`;
      const newPhase: SeasonPhase = {
        id: phaseId,
        seasonId: selectedSeasonId,
        name: faseType,
        startDate: startDatum,
        endDate: hasEindDatum && eindDatum ? eindDatum : startDatum,
        description: omschrijving || `Seizoensfase ${faseType} van ${targetSeason?.name || 'seizoen'}`
      };

      // Sla de fase op in de betreffende season
      db.seasons = db.seasons.map(s => {
        if (s.id === selectedSeasonId) {
          const updatedPhases = [...(s.phases || []), newPhase];
          return { ...s, phases: updatedPhases };
        }
        return s;
      });

      // Voeg toe aan centrale agenda
      const calEvt: CalendarEvent = {
        id: `evt-${timestamp}`,
        title: `Fase: ${faseType} (${targetSeason?.name || 'Seizoen'})`,
        type: 'Speelronde',
        category: 'Speelronde',
        date: startDatum,
        endDate: hasEindDatum ? eindDatum : undefined,
        time: beginTijd,
        endTime: eindTijd,
        location: defaultLoc,
        description: `Seizoensfase ${faseType} voor ${targetSeason?.name}. Van ${startDatum} tot ${eindDatum || startDatum}.`,
        seasonId: selectedSeasonId,
        seasonPhaseId: phaseId,
        rsvps: {}
      };

      db.calendarEvents = [...(db.calendarEvents || []), calEvt];
      createdCount = 1;

    } else if (selectedType === 'Games') {
      // 3. GAMES (WEDSTRIJDEN)
      const homeName = homeTeamIsTBD ? 'TBD' : (db.teams.find(t => t.id === homeTeamId)?.name || 'Thuisteam');
      const awayName = awayTeamIsTBD ? 'TBD' : (db.teams.find(t => t.id === awayTeamId)?.name || 'Uitteam');

      const allGameDates = Array.from(new Set([startDatum, ...tussendatums, ...(hasEindDatum && eindDatum ? [eindDatum] : [])])).sort();

      const newMatches: Match[] = [];
      const gamesToCreate = Math.max(1, aantalGames);

      for (let g = 0; g < gamesToCreate; g++) {
        // Verdeel over gekozen datums
        const gameDate = allGameDates[g % allGameDates.length] || startDatum;
        const matchId = `match-${timestamp}-${g}`;

        newMatches.push({
          id: matchId,
          leagueId: selectedLeagueId,
          seasonId: gameSeasonId || undefined,
          seasonPhaseName: gamePhaseName,
          homeTeamId: homeTeamIsTBD ? 'tbd' : homeTeamId,
          awayTeamId: awayTeamIsTBD ? 'tbd' : awayTeamId,
          date: gameDate,
          time: beginTijd,
          endTime: eindTijd,
          location: defaultLoc,
          round: speelrondeNaam ? `${speelrondeNaam} ${gamesToCreate > 1 ? `#${g+1}` : ''}`.trim() : 'Wedstrijd',
          ruleset: ruleset || 'Standard House League Rules',
          status: 'Gepland',
          homeScore: 0,
          awayScore: 0,
          events: []
        });
      }

      db.matches = [...db.matches, ...newMatches];
      createdCount = newMatches.length;

      // Log social activity
      const logAct = {
        id: `act-${timestamp}`,
        personId: db.currentUser?.personId || 'system',
        activityType: 'ScheduleMatch' as any,
        description: `${createdCount} wedstrijd(en) ingepland: ${homeName} vs ${awayName} (${ruleset || 'Standard Rules'}) op ${startDatum}.`,
        createdAt: new Date().toISOString()
      };
      db.socialActivities = [logAct, ...(db.socialActivities || [])];

    } else {
      // 4. OVERIGE OPTIES (Tournooi, Training, Meeting, Overige)
      const allDates = Array.from(new Set([startDatum, ...tussendatums, ...(hasEindDatum && eindDatum ? [eindDatum] : [])])).sort();

      const eventTypeMap: Record<string, CalendarEvent['type']> = {
        'Tournooi': 'Toernooi',
        'Training': 'Training',
        'Meeting': 'Vergadering',
        'Overige': 'Overige'
      };

      const newEvents: CalendarEvent[] = allDates.map((dateStr, idx) => ({
        id: `evt-${timestamp}-${idx}`,
        title: titel || `${selectedType} (${dateStr})`,
        type: eventTypeMap[selectedType] || 'Evenement',
        category: selectedType,
        date: dateStr,
        endDate: hasEindDatum ? eindDatum : undefined,
        tussendatums: tussendatums.length > 0 ? tussendatums : undefined,
        time: beginTijd,
        endTime: eindTijd,
        tussentijden: tussentijden.length > 0 ? tussentijden : undefined,
        location: defaultLoc,
        description: omschrijving || `${selectedType} gepland voor ${doelgroep}.`,
        seasonId: linkedSeasonId || undefined,
        relatedLeagueId: selectedLeagueId,
        rsvps: {}
      }));

      const newDb = addCalendarEvents(newEvents);
      createdCount = newEvents.length;
      onUpdateDb(newDb);
    }

    // Give visual confirmation
    setSuccessMessage(`Succesvol ${createdCount} ${selectedType.toLowerCase()}(s) opgeslagen in de centrale planner!`);
    setTimeout(() => setSuccessMessage(null), 5000);

    // Scroll back to top or reset form fields
    setTitel('');
    setOmschrijving('');
  };

  // Verwijderen
  const handleDeleteMatch = (matchId: string) => {
    if (!confirm('Weet je zeker dat je deze geplande wedstrijd wilt verwijderen?')) return;
    const newDb = deleteMatch(matchId);
    onUpdateDb(newDb);
  };

  const handleDeleteCalendarEvent = (eventId: string) => {
    if (!confirm('Weet je zeker dat je deze geplande activiteit wilt verwijderen?')) return;
    const newDb = deleteCalendarEvent(eventId);
    onUpdateDb(newDb);
  };

  // Alle geplande items verzamelen
  const allScheduledItems = [
    ...db.matches.filter(m => m.status === 'Gepland').map(m => {
      const homeName = m.homeTeamId === 'tbd' ? 'TBD (To Be Determined)' : (db.teams.find(t => t.id === m.homeTeamId)?.name || 'Onbekend');
      const awayName = m.awayTeamId === 'tbd' ? 'TBD (To Be Determined)' : (db.teams.find(t => t.id === m.awayTeamId)?.name || 'Onbekend');
      const seasonName = db.seasons.find(s => s.id === m.seasonId)?.name;

      return {
        id: m.id,
        itemType: 'Match' as const,
        category: 'Games' as ActivityType,
        title: `${homeName} vs ${awayName}`,
        subtitle: `${m.round || 'Wedstrijd'} ${m.seasonPhaseName ? `• ${m.seasonPhaseName}` : ''} ${seasonName ? `(${seasonName})` : ''} • Regels: ${m.ruleset || 'Standard'}`,
        date: m.date,
        time: m.time,
        endTime: m.endTime,
        tussendatums: undefined as string[] | undefined,
        tussentijden: undefined as string[] | undefined,
        location: m.location || db.association?.locations?.[0]?.name || 'Kardinge',
        rawMatch: m
      };
    }),
    ...(db.calendarEvents || []).map(e => {
      const seasonName = db.seasons.find(s => s.id === e.seasonId)?.name;
      return {
        id: e.id,
        itemType: 'Event' as const,
        category: (e.category || e.type) as ActivityType,
        title: e.title,
        subtitle: `${e.description} ${seasonName ? `• Gekoppeld aan: ${seasonName}` : ''}`,
        date: e.date,
        endDate: e.endDate,
        tussendatums: e.tussendatums,
        time: e.time,
        endTime: e.endTime,
        tussentijden: e.tussentijden,
        location: e.location || db.association?.locations?.[0]?.name || 'Kardinge',
        rawEvent: e
      };
    })
  ].sort((a, b) => new Date(`${a.date}T${a.time || '00:00'}`).getTime() - new Date(`${b.date}T${b.time || '00:00'}`).getTime());

  // Gefilterde items
  const filteredItems = allScheduledItems.filter(item => {
    if (activeCategoryFilter !== 'Alle' && item.category !== activeCategoryFilter) return false;
    if (filterDatum && item.date !== filterDatum) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!item.title.toLowerCase().includes(q) && !(item.subtitle || '').toLowerCase().includes(q) && !item.location.toLowerCase().includes(q)) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="space-y-8" id="planner-workflow-root">
      {/* HEADER HERO */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
          <CalendarIcon className="w-56 h-56 text-white" />
        </div>
        <div className="relative z-10 max-w-3xl">
          <h2 className="text-2xl md:text-4xl font-black uppercase tracking-tight text-white mb-2">
            Module <span className="text-slate-900">Planner</span>
          </h2>
          <p className="text-slate-300 font-sans text-sm md:text-base leading-relaxed">
            Kies als eerste het type activiteit dat je wilt plannen. Vervolgens worden de bijbehorende specifieke vragen en datum/tijdopties getoond.
          </p>
        </div>
      </div>

      {/* SUCCESS NOTIFICATION */}
      {successMessage && (
        <div className="bg-slate-100 border-2 border-slate-200/30 rounded-2xl p-4 flex items-center gap-3 text-slate-900 shadow-sm animate-fadeIn">
          <CheckCircleIcon className="w-6 h-6 text-slate-900 shrink-0" />
          <div className="font-bold text-xs md:text-sm">{successMessage}</div>
        </div>
      )}

      {/* HOOFDSTAP 1: KIES HET TYPE ACTIVITEIT */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 md:p-8 space-y-6">
        <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
              Stap 1 van 2
            </span>
            <h3 className="text-xl font-black uppercase text-slate-950 mt-1">
              Selecteer het Type Activiteit
            </h3>
          </div>
          <div className="text-xs font-bold text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 flex items-center gap-1.5">
            <MapPinIcon className="w-4 h-4 text-slate-900" />
            Locatie: <strong className="text-slate-900">{locatie}</strong>
          </div>
        </div>

        {/* ACTIVITEITEN GRID SELECTOR */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {[
            { 
              type: 'Seizoen' as ActivityType, 
              icon: TrophyIcon, 
              label: 'Seizoen', 
              desc: 'Naam, jaar/jaren, van-tot datums', 
              color: selectedType === 'Seizoen' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Seizoensfase' as ActivityType, 
              icon: LayersIcon, 
              label: 'Seizoensfase', 
              desc: 'Pre-Season, Regular, Playoffs, Tournament', 
              color: selectedType === 'Seizoensfase' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Games' as ActivityType, 
              icon: ActivityIcon, 
              label: 'Games (Wedstrijden)', 
              desc: 'Aantal, datums, tijden, teams (of TBD), ruleset', 
              color: selectedType === 'Games' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Tournooi' as ActivityType, 
              icon: FlagIcon, 
              label: 'Tournooi', 
              desc: 'Toernooi-evenementen (los of gekoppeld aan seizoen)', 
              color: selectedType === 'Tournooi' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Training' as ActivityType, 
              icon: DumbbellIcon, 
              label: 'Training', 
              desc: 'IJstraining of droogtraining (los of per seizoen)', 
              color: selectedType === 'Training' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Meeting' as ActivityType, 
              icon: UsersIcon, 
              label: 'Meeting / Bijeenkomst', 
              desc: 'Vergaderingen en overleg (los of gekoppeld)', 
              color: selectedType === 'Meeting' ? 'bg-slate-100 text-white border-slate-200 shadow-lg' : 'bg-slate-100/60 border-slate-200 text-slate-900 hover:bg-slate-100' 
            },
            { 
              type: 'Overige' as ActivityType, 
              icon: FileTextIcon, 
              label: 'Overige Activiteit', 
              desc: 'Vrije clubactiviteiten & overige events', 
              color: selectedType === 'Overige' ? 'bg-slate-800 text-white border-slate-800 shadow-lg' : 'bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200' 
            },
          ].map((item) => {
            const IconComp = item.icon;
            const isSelected = selectedType === item.type;
            return (
              <button
                key={item.type}
                type="button"
                onClick={() => setSelectedType(item.type)}
                className={`p-4 rounded-2xl border-2 text-left transition-all flex flex-col justify-between space-y-3 cursor-pointer group ${item.color}`}
              >
                <div className="flex items-center justify-between">
                  <div className={`p-2 rounded-xl shrink-0 ${isSelected ? 'bg-white/20 text-white' : 'bg-white shadow-sm border border-slate-200'}`}>
                    <IconComp className="w-5 h-5" />
                  </div>
                  {isSelected && <CheckCircleIcon className="w-5 h-5 text-white" />}
                </div>
                <div>
                  <div className="font-extrabold text-sm">{item.label}</div>
                  <div className={`text-[11px] leading-tight mt-1 ${isSelected ? 'text-white/80' : 'text-slate-500'}`}>
                    {item.desc}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* HOOFDSTAP 2: DE VRAGEN & FORMULIER VOOR HET GEKOZEN TYPE */}
      {selectedType ? (
        <form onSubmit={handleSubmitPlanning} className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 md:p-8 space-y-8 animate-fadeIn">
          <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                Stap 2 van 2
              </span>
              <h3 className="text-xl font-black uppercase text-slate-950 mt-1 flex items-center gap-2">
                Details voor: <span className="text-slate-900">{selectedType}</span>
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setSelectedType(null)}
              className="text-xs font-bold text-slate-500 hover:text-slate-900 underline"
            >
              Andere activiteit kiezen
            </button>
          </div>

          {/* FORMULIER INHOUD VOOR: SEIZOEN */}
          {selectedType === 'Seizoen' && (
            <div className="space-y-6">
              <div className="bg-slate-100/50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-900 flex items-start gap-2.5">
                <Info className="w-5 h-5 text-slate-900 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-extrabold block">Seizoen inrichten</strong>
                  Geef de naam, het seizoensjaar en de van-tot datums op voor dit nieuwe seizoen.
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Naam van het Seizoen <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="bijv. Eredivisie House League 2026-2027"
                    value={seizoenNaam}
                    onChange={(e) => setSeizoenNaam(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Jaar / Jaren <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="bijv. 2026-2027"
                    value={seizoenJaren}
                    onChange={(e) => setSeizoenJaren(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Van (Startmaand / Datum) <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={startDatum}
                    onChange={(e) => setStartDatum(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tot (Eindmaand / Datum) <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={hasEindDatum ? eindDatum : `${new Date(startDatum).getFullYear() + 1}-04-30`}
                    onChange={(e) => { setHasEindDatum(true); setEindDatum(e.target.value); }}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Koppel aan Competitie</label>
                <select
                  value={selectedLeagueId}
                  onChange={(e) => setSelectedLeagueId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                >
                  {db.leagues.map(l => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* FORMULIER INHOUD VOOR: SEIZOENSFASE */}
          {selectedType === 'Seizoensfase' && (
            <div className="space-y-6">
              <div className="bg-slate-100/50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-900 flex items-start gap-2.5">
                <LayersIcon className="w-5 h-5 text-slate-900 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-extrabold block">Seizoensfase instellen</strong>
                  Koppel deze fase aan een bestaand seizoen (Pre-Season, Regular Season, Playoffs of Tournament).
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Koppel aan Bestaand Seizoen <span className="text-slate-900">*</span>
                </label>
                <select
                  value={selectedSeasonId}
                  onChange={(e) => setSelectedSeasonId(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                >
                  {db.seasons.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.years || '2026'})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                  Selecteer Type Seizoensfase <span className="text-slate-900">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {(['Pre-Season', 'Regular Season', 'Playoffs', 'Tournament'] as const).map(phase => (
                    <button
                      key={phase}
                      type="button"
                      onClick={() => setFaseType(phase)}
                      className={`p-3 rounded-xl border-2 text-center text-xs font-extrabold transition ${
                        faseType === phase
                          ? 'bg-slate-100 text-white border-slate-200 shadow-md'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {phase}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Van (Startdatum Fase) <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={startDatum}
                    onChange={(e) => setStartDatum(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tot (Einddatum Fase) <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={hasEindDatum ? eindDatum : startDatum}
                    onChange={(e) => { setHasEindDatum(true); setEindDatum(e.target.value); }}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>
            </div>
          )}

          {/* FORMULIER INHOUD VOOR: GAMES (WEDSTRIJDEN) */}
          {selectedType === 'Games' && (
            <div className="space-y-6">
              <div className="bg-slate-100/50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-900 flex items-start gap-2.5">
                <ActivityIcon className="w-5 h-5 text-slate-900 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-extrabold block">Wedstrijden / Games Inplannen</strong>
                  Plan 1 of meerdere wedstrijden. Je kunt ze koppelen aan een seizoen en seizoensfase. Teams kunnen ook TBD (To Be Determined) zijn.
                </div>
              </div>

              {/* KOPPELING MET SEIZOEN & SEIZOENSFASE */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Koppel aan Seizoen (Optioneel)
                  </label>
                  <select
                    value={gameSeasonId}
                    onChange={(e) => setGameSeasonId(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  >
                    <option value="">-- Geen Seizoen (Losse Game) --</option>
                    {db.seasons.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Seizoensfase
                  </label>
                  <select
                    value={gamePhaseName}
                    onChange={(e) => setGamePhaseName(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  >
                    <option value="Regular Season">Regular Season</option>
                    <option value="Pre-Season">Pre-Season</option>
                    <option value="Playoffs">Playoffs</option>
                    <option value="Tournament">Tournament</option>
                  </select>
                </div>
              </div>

              {/* AANTAL GAMES & DATUMS */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Aantal Games
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={aantalGames}
                    onChange={(e) => setAantalGames(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Speeldatum / Startdatum <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={startDatum}
                    onChange={(e) => setStartDatum(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Einddatum (Optioneel)
                  </label>
                  <input
                    type="date"
                    value={hasEindDatum ? eindDatum : ''}
                    onChange={(e) => { setHasEindDatum(true); setEindDatum(e.target.value); }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              {/* TUSSENDATUMS TOEVOEGEN */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase">
                  Tussendatums / Extra Speeldagen voor meerdere games
                </label>
                
                {tussendatums.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {tussendatums.map((d) => (
                      <span key={d} className="inline-flex items-center gap-1.5 bg-white border border-slate-300 px-2.5 py-1 rounded-lg text-xs font-bold text-slate-800 shadow-sm">
                        {d}
                        <button type="button" onClick={() => handleRemoveTussendatum(d)} className="text-slate-400 hover:text-slate-900">
                          <XIcon className="w-3.5 h-3.5" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex gap-2">
                  <input
                    type="date"
                    value={newTussendatumInput}
                    onChange={(e) => setNewTussendatumInput(e.target.value)}
                    className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-slate-200"
                  />
                  <button
                    type="button"
                    onClick={handleAddTussendatum}
                    disabled={!newTussendatumInput}
                    className="bg-slate-200 hover:bg-slate-800 hover:text-white text-slate-800 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1 transition-all disabled:opacity-50"
                  >
                    <PlusIcon className="w-3.5 h-3.5" /> Tussendatum Toevoegen
                  </button>
                </div>
              </div>

              {/* TIJDEN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Begintijd <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="time"
                    value={beginTijd}
                    onChange={(e) => setBeginTijd(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Eindtijd <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="time"
                    value={eindTijd}
                    onChange={(e) => setEindTijd(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              {/* TEAMS (INCLUSIEF TBD OPTIE) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                {/* THUISTEAM */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase">
                      Thuisteam
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer text-xs font-extrabold text-slate-900">
                      <input
                        type="checkbox"
                        checked={homeTeamIsTBD}
                        onChange={(e) => setHomeTeamIsTBD(e.target.checked)}
                        className="rounded text-slate-900 focus:ring-red-500"
                      />
                      Is TBD
                    </label>
                  </div>
                  {homeTeamIsTBD ? (
                    <div className="bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs font-black text-slate-900">
                      Thuisteam: TBD (To Be Determined)
                    </div>
                  ) : (
                    <select
                      value={homeTeamId}
                      onChange={(e) => setHomeTeamId(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                    >
                      {db.teams.map(t => (
                        <option key={t.id} value={t.id}>{t.name} ({t.city})</option>
                      ))}
                    </select>
                  )}
                </div>

                {/* UITTEAM */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase">
                      Uitteam
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer text-xs font-extrabold text-slate-900">
                      <input
                        type="checkbox"
                        checked={awayTeamIsTBD}
                        onChange={(e) => setAwayTeamIsTBD(e.target.checked)}
                        className="rounded text-slate-900 focus:ring-red-500"
                      />
                      Is TBD
                    </label>
                  </div>
                  {awayTeamIsTBD ? (
                    <div className="bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs font-black text-slate-900">
                      Uitteam: TBD (To Be Determined)
                    </div>
                  ) : (
                    <select
                      value={awayTeamId}
                      onChange={(e) => setAwayTeamId(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                    >
                      {db.teams.map(t => (
                        <option key={t.id} value={t.id}>{t.name} ({t.city})</option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              {/* RULESET & RONDE */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Ruleset / Reglement
                  </label>
                  <select
                    value={ruleset}
                    onChange={(e) => setRuleset(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  >
                    <option value="Standard House League Rules">Standard House League Rules</option>
                    <option value="IIHF Non-Bodychecking">IIHF Non-Bodychecking</option>
                    <option value="3v3 Overtime Tournament Rules">3v3 Overtime Tournament Rules</option>
                    <option value="Custom Ruleset">Custom Ruleset</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Speelronde / Aanduiding
                  </label>
                  <input
                    type="text"
                    value={speelrondeNaam}
                    onChange={(e) => setSpeelrondeNaam(e.target.value)}
                    placeholder="bijv. Speelronde 1"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>
            </div>
          )}

          {/* FORMULIER INHOUD VOOR: OVERIGE OPTIES (Tournooi, Training, Meeting, Overige) */}
          {(selectedType === 'Tournooi' || selectedType === 'Training' || selectedType === 'Meeting' || selectedType === 'Overige') && (
            <div className="space-y-6">
              <div className="bg-slate-100/50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-900 flex items-start gap-2.5">
                <FileTextIcon className="w-5 h-5 text-slate-900 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-extrabold block">{selectedType} Inplannen</strong>
                  Je kunt deze activiteit los plannen, of optioneel koppelen aan een gemaakte seizoen.
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Koppel aan Seizoen (Optioneel)
                </label>
                <select
                  value={linkedSeasonId}
                  onChange={(e) => setLinkedSeasonId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                >
                  <option value="">-- Los Plannen (Geen Seizoen) --</option>
                  {db.seasons.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.years || '2026'})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Titel van Activiteit <span className="text-slate-900">*</span>
                </label>
                <input
                  type="text"
                  placeholder={`bijv. ${selectedType === 'Tournooi' ? 'Groningen Ice Cup 2026' : selectedType === 'Training' ? 'IJstraining Powerplay & Snelheid' : selectedType === 'Meeting' ? 'Team Managers Bijeenkomst' : 'Club Activiteit'}`}
                  value={titel}
                  onChange={(e) => setTitel(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                />
              </div>

              {/* DATUMS */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Startdatum <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="date"
                    value={startDatum}
                    onChange={(e) => setStartDatum(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Einddatum (Optioneel)
                  </label>
                  <input
                    type="date"
                    value={hasEindDatum ? eindDatum : ''}
                    onChange={(e) => { setHasEindDatum(true); setEindDatum(e.target.value); }}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              {/* TIJDEN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Begintijd <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="time"
                    value={beginTijd}
                    onChange={(e) => setBeginTijd(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Eindtijd <span className="text-slate-900">*</span>
                  </label>
                  <input
                    type="time"
                    value={eindTijd}
                    onChange={(e) => setEindTijd(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Doelgroep / Deelnemers</label>
                <input
                  type="text"
                  placeholder="bijv. Alle Teams, Divisie A, of Kapiteins"
                  value={doelgroep}
                  onChange={(e) => setDoelgroep(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Omschrijving</label>
                <textarea
                  rows={2}
                  placeholder="Details, kleedkamers of overige opmerkingen..."
                  value={omschrijving}
                  onChange={(e) => setOmschrijving(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-medium text-slate-900 focus:outline-none focus:border-slate-200"
                />
              </div>
            </div>
          )}

          {/* SUBMIT BUTTON */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-400 font-medium">
              Gegevens worden direct opgeslagen in de centrale database.
            </div>
            <button
              type="submit"
              className="w-full sm:w-auto bg-slate-900 hover:bg-slate-950 text-white font-black text-xs uppercase tracking-wider px-8 py-3.5 rounded-xl shadow-lg transition transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2"
            >
              <CheckCircleIcon className="w-4 h-4" />
              Nieuwe {selectedType} Inplannen
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-slate-50 border-2 border-dashed border-slate-300 rounded-3xl p-8 text-center space-y-2 text-slate-500">
          <HelpCircle className="w-8 h-8 text-slate-400 mx-auto" />
          <p className="font-extrabold text-sm text-slate-700">Kies hierboven een activiteitstype om het bijbehorende formulier te openen</p>
          <p className="text-xs">Je kunt seizoenen, seizoensfasen, wedstrijden, toernooien, trainingen, meetings en overige clubactiviteiten beheren.</p>
        </div>
      )}

      {/* OVERZICHT VAN ALLE GEPLANDE ACTIVITEITEN */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 md:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-4 gap-4">
          <div>
            <h3 className="text-lg md:text-xl font-black uppercase text-slate-950">
              Centrale Agenda &amp; Ingeplande Activiteiten
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Totaal gepland: <strong className="text-slate-900">{filteredItems.length}</strong> item(s)
            </p>
          </div>

          {/* Zoekbalk & Datumfilter */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <SearchIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Zoek in planner..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-slate-200"
              />
            </div>
            <input
              type="date"
              value={filterDatum}
              onChange={(e) => setFilterDatum(e.target.value)}
              className="py-1.5 px-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            />
            {filterDatum && (
              <button
                type="button"
                onClick={() => setFilterDatum('')}
                className="text-xs text-slate-900 font-bold hover:underline"
              >
                Reset
              </button>
            )}
          </div>
        </div>

        {/* Categorie Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 hide-scrollbar border-b border-slate-100">
          {['Alle', 'Seizoen', 'Seizoensfase', 'Games', 'Tournooi', 'Training', 'Meeting', 'Overige'].map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategoryFilter(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                activeCategoryFilter === cat
                  ? 'bg-slate-900 text-white shadow'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Lijst van Geplande Items */}
        <div className="divide-y divide-slate-100">
          {filteredItems.map((item) => {
            const badgeColors: Record<ActivityType, string> = {
              'Seizoen': 'bg-slate-100 text-slate-900 border-slate-200',
              'Seizoensfase': 'bg-slate-100 text-slate-900 border-slate-200',
              'Games': 'bg-slate-100 text-slate-900 border-slate-200',
              'Tournooi': 'bg-slate-100 text-slate-900 border-slate-200',
              'Training': 'bg-slate-100 text-slate-900 border-slate-200',
              'Meeting': 'bg-slate-100 text-slate-900 border-slate-200',
              'Overige': 'bg-slate-100 text-slate-700 border-slate-200',
            };

            return (
              <div key={item.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/80 rounded-2xl p-3 transition">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {item.date}
                    </span>
                    <span className="text-xs font-mono text-slate-500 flex items-center gap-1">
                      <ClockIcon className="w-3 h-3 text-slate-400" />
                      {item.time || '19:30'} {item.endTime ? `- ${item.endTime}` : ''}
                    </span>
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md border ${badgeColors[item.category] || 'bg-slate-100'}`}>
                      {item.category}
                    </span>
                  </div>

                  <h4 className="font-extrabold text-sm md:text-base text-slate-950">
                    {item.title}
                  </h4>

                  {item.subtitle && (
                    <p className="text-xs text-slate-500 leading-normal line-clamp-2">
                      {item.subtitle}
                    </p>
                  )}

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                    <span className="flex items-center gap-1 font-semibold">
                      <MapPinIcon className="w-3 h-3 text-slate-900" />
                      {item.location}
                    </span>
                    {item.tussentijden && item.tussentijden.length > 0 && (
                      <span className="font-mono text-slate-400">
                        • Tussentijden: {item.tussentijden.join(', ')}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {item.itemType === 'Match' ? (
                    <button
                      type="button"
                      onClick={() => handleDeleteMatch(item.id)}
                      className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition"
                      title="Wedstrijd Verwijderen"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleDeleteCalendarEvent(item.id)}
                      className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition"
                      title="Activiteit Verwijderen"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {filteredItems.length === 0 && (
            <div className="text-center py-12 text-slate-400 space-y-2">
              <CalendarIcon className="w-10 h-10 mx-auto text-slate-300" />
              <p className="text-xs font-semibold">Geen geplande activiteiten gevonden.</p>
              <p className="text-[11px] text-slate-400">Selecteer een type activiteit hierboven om een nieuw item in te plannen.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
