import React, { useState } from 'react';
import { AppDatabase } from '../types';
import { 
  Settings, AlertTriangle, Terminal, Database, Activity, 
  Network, GitCommit, BookOpen, Code, Users, Play, X, FileSpreadsheet
} from 'lucide-react';
import { GoogleSheetsPanel } from './GoogleSheetsPanel';

interface AdminModuleProps {
  db: AppDatabase;
  onUpdateDb: (db: AppDatabase) => void;
}

export default function AdminModule({ db, onUpdateDb }: AdminModuleProps) {
  const [activeSubTab, setActiveSubTab] = useState<string>('google-sheets');

  const adminTabs = [
    { id: 'google-sheets', label: 'Google Sheets DB', icon: <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> },
    { id: 'app-settings', label: 'App Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'troubleshooting', label: 'Troubleshooting', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'dev-console', label: 'Developer Console', icon: <Terminal className="w-4 h-4" /> },
    { id: 'record-viewer', label: 'Record Viewer', icon: <Database className="w-4 h-4" /> },
    { id: 'network-viewer', label: 'Network Viewer', icon: <Network className="w-4 h-4" /> },
    { id: 'data-hierarchy', label: 'Visual Data Hierarchy', icon: <Activity className="w-4 h-4" /> },
    { id: 'changelog', label: 'Change Log', icon: <GitCommit className="w-4 h-4" /> },
    { id: 'domains', label: 'Domain Definitions', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'functions', label: 'Functions Viewer', icon: <Code className="w-4 h-4" /> },
    { id: 'impersonate', label: 'Impersonate User', icon: <Users className="w-4 h-4" /> },
    { id: 'bulk-crud', label: 'Bulk Database CRUD', icon: <Play className="w-4 h-4" /> },
  ];

  return (
    <div className="flex h-[calc(100vh-80px)] bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-slate-200 flex flex-col h-full shrink-0">
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-lg font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-slate-900" />
            Admin Panel
          </h2>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
          {adminTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-all ${
                activeSubTab === tab.id
                  ? 'bg-slate-100 text-slate-900 border border-slate-200 shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-transparent'
              }`}
            >
              <div className={activeSubTab === tab.id ? 'text-slate-900' : 'text-slate-400'}>
                {tab.icon}
              </div>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-50">
        <div className="max-w-6xl mx-auto bg-white rounded-3xl shadow-sm border border-slate-200 p-6 min-h-full">
          <div className="mb-6 pb-4 border-b border-slate-100">
            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
              {adminTabs.find(t => t.id === activeSubTab)?.icon}
              {adminTabs.find(t => t.id === activeSubTab)?.label}
            </h3>
          </div>
          
          <div className="text-slate-600 text-sm font-medium leading-relaxed">
            {activeSubTab === 'google-sheets' ? (
              <GoogleSheetsPanel db={db} onUpdateDb={onUpdateDb} />
            ) : (
              <>
                <p>De inhoud voor <strong>{adminTabs.find(t => t.id === activeSubTab)?.label}</strong> is nog in ontwikkeling (work-in-progress).</p>
            
            {activeSubTab === 'app-settings' && (
              <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-4">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-xs">Global Configuration</h4>
                <div className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg">
                  <span className="font-bold text-sm text-slate-700">Maintenance Mode</span>
                  <input type="checkbox" className="toggle-checkbox" />
                </div>
                <div className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg">
                  <span className="font-bold text-sm text-slate-700">Allow New Registrations</span>
                  <input type="checkbox" defaultChecked className="toggle-checkbox" />
                </div>
              </div>
            )}

            {activeSubTab === 'dev-console' && (
              <div className="mt-6 bg-slate-900 rounded-xl p-4 font-mono text-xs text-slate-900">
                <p>Welcome to Blackout GHL Developer Console</p>
                <p>&gt; System initialized...</p>
                <p>&gt; Waiting for commands...</p>
                <div className="flex gap-2 mt-4">
                  <span className="text-slate-500">&gt;</span>
                  <input type="text" className="bg-transparent outline-none flex-1" placeholder="Enter command" />
                </div>
              </div>
            )}
            
            {activeSubTab === 'troubleshooting' && (
              <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
                <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg flex items-center gap-3 text-slate-900 text-sm">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Warning: 3 Matches missing location data</span>
                </div>
                <div className="p-3 bg-white border border-slate-200 rounded-lg flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-700">Clear Cache & Local Storage</span>
                  <button className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded text-xs font-bold hover:bg-slate-300">Run</button>
                </div>
              </div>
            )}
            {activeSubTab === 'impersonate' && (
              <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider mb-4 text-xs">Simuleer inloggen als:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {db.persons.map(p => (
                    <button key={p.id} className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg hover:border-slate-200 hover:shadow-sm transition-all text-left">
                      <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                        {p.name.substring(0,2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-900">{p.name}</div>
                        <div className="text-[10px] text-slate-500">{(p as any).email || 'Geen email'}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {activeSubTab === 'bulk-crud' && (
              <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50">
                 <p className="mb-4">Geavanceerde acties om bulk data toe te voegen of te bewerken.</p>
                 <div className="flex gap-3">
                   <button className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold uppercase hover:bg-slate-800">
                     Seed Dummy Data
                   </button>
                   <button className="px-4 py-2 bg-slate-100 text-white rounded-lg text-xs font-bold uppercase hover:bg-slate-100">
                     Clear Database
                   </button>
                 </div>
              </div>
            )}
            
            {activeSubTab === 'data-hierarchy' && (
              <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50 overflow-auto">
                 <pre className="text-[10px] font-mono text-slate-700 bg-white p-4 rounded border border-slate-200">
{`AppDatabase {
  users: User[]
  persons: Person[]
  leagues: League[]
  teams: Team[]
  matches: Match[]
}`}
                 </pre>
              </div>
            )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
