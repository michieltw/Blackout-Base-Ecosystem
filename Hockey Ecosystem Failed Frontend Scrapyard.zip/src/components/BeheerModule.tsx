import React, { useState } from 'react';
import { AppDatabase } from '../types';
import { Users, Trophy, Layers, Settings, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BeheerModuleProps {
  db: AppDatabase;
  onUpdateDb: (db: AppDatabase) => void;
  setActiveTab: (tab: string) => void;
}

export default function BeheerModule({ db, onUpdateDb, setActiveTab }: BeheerModuleProps) {
  const options = [
    {
      id: 'manager',
      title: 'Team Beheer',
      description: '(Line-ups, Teamselectie, Teaminstellingen)',
      icon: <Users className="w-8 h-8 text-slate-900" />
    },
    {
      id: 'league',
      title: 'Competitie Beheer',
      description: '(Beheer instellingen die gelden voor de hele competitie of specifieke divisies)',
      icon: <Trophy className="w-8 h-8 text-slate-900" />
    },
    {
      id: 'multi-league',
      title: 'Multi-League Manager',
      description: '(Beheer meerdere competities)',
      icon: <Layers className="w-8 h-8 text-slate-900" />
    },
    {
      id: 'admin',
      title: 'Admin',
      description: '(Veelzijdige en uitgebreide beheeropties m.b.t. App-settings, Troubleshooting, Developer Console, Record viewer, Record network viewer, Visual Data Hierarchy, Change log, Domain Defenitions, Functions viewer en Bulk Database CRUD)',
      icon: <Settings className="w-8 h-8 text-slate-900" />
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <h2 className="text-xl font-black uppercase tracking-tight text-slate-900">
            Kies een module
          </h2>
          <button 
            onClick={() => setActiveTab('comp-gamecenter')} 
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-full transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 md:p-8 overflow-y-auto hide-scrollbar bg-slate-50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {options.map(opt => (
              <button
                key={opt.id}
                onClick={() => setActiveTab(opt.id)}
                className="flex flex-col text-left p-6 rounded-2xl border-2 border-slate-200 hover:border-slate-300 hover:shadow-md transition-all group bg-white relative overflow-hidden"
              >
                <div className="absolute -right-4 -top-4 opacity-5 group-hover:scale-110 transition-transform duration-500">
                  {React.cloneElement(opt.icon, { className: 'w-32 h-32 text-slate-900' })}
                </div>
                <div className="mb-4 p-3 bg-slate-50 rounded-xl inline-block border border-slate-100 group-hover:scale-110 group-hover:-rotate-3 transition-transform">
                  {opt.icon}
                </div>
                <h3 className="text-lg font-black text-slate-900 mb-2 uppercase tracking-wide relative z-10">{opt.title}</h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed relative z-10">
                  {opt.description}
                </p>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
