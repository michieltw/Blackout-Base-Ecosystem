import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { AppDatabase } from '../types';

let app: any;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApps()[0];
}

const auth = getAuth(app);
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');

let isSigningIn = false;
let cachedAccessToken: string | null = sessionStorage.getItem('ghl_google_access_token');

export const initGoogleAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      try {
        if (!cachedAccessToken) {
          cachedAccessToken = sessionStorage.getItem('ghl_google_access_token');
        }
        if (cachedAccessToken) {
          if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
        } else if (!isSigningIn) {
          if (onAuthFailure) onAuthFailure();
        }
      } catch (err) {
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      sessionStorage.removeItem('ghl_google_access_token');
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const signInWithGoogleSheets = async (): Promise<{ user: User; accessToken: string }> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Kon geen Google OAuth access token ophalen.');
    }
    cachedAccessToken = credential.accessToken;
    sessionStorage.setItem('ghl_google_access_token', cachedAccessToken);
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-In error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const signOutGoogle = async () => {
  cachedAccessToken = null;
  sessionStorage.removeItem('ghl_google_access_token');
  await signOut(auth);
};

export const getGoogleAccessToken = (): string | null => {
  return cachedAccessToken;
};

// Google Sheets API Helpers
export async function createGoogleSpreadsheet(accessToken: string, title: string = 'GIJS House League Database'): Promise<string> {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: title
      },
      sheets: [
        { properties: { title: 'Teams' } },
        { properties: { title: 'Persons' } },
        { properties: { title: 'Matches' } },
        { properties: { title: 'Calendar' } },
        { properties: { title: 'Leagues' } },
        { properties: { title: 'Seasons' } },
        { properties: { title: 'Divisions' } },
        { properties: { title: 'Locations' } },
        { properties: { title: 'Settings' } }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Fout bij aanmaken Google Spreadsheet');
  }

  const data = await response.json();
  return data.spreadsheetId;
}

// Helper to ensure all required sheet tabs exist in the target spreadsheet
async function ensureSpreadsheetTabsExist(accessToken: string, spreadsheetId: string): Promise<void> {
  const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`
    }
  });

  if (!metaRes.ok) {
    const err = await metaRes.json();
    throw new Error(err.error?.message || 'Kan spreadsheet metadata niet ophalen. Controleer het Spreadsheet ID.');
  }

  const metaData = await metaRes.json();
  const existingSheets = (metaData.sheets || []).map((s: any) => s.properties?.title);

  const requiredSheets = ['Teams', 'Persons', 'Matches', 'Calendar', 'Leagues', 'Seasons', 'Divisions', 'Locations', 'Settings'];
  const missingSheets = requiredSheets.filter(title => !existingSheets.includes(title));

  if (missingSheets.length > 0) {
    const requests = missingSheets.map(title => ({
      addSheet: {
        properties: {
          title: title
        }
      }
    }));

    const updateRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ requests })
    });

    if (!updateRes.ok) {
      const err = await updateRes.json();
      throw new Error(err.error?.message || 'Fout bij aanmaken ontbrekende werkbladen');
    }
  }
}

export async function exportDbToGoogleSheet(accessToken: string, spreadsheetId: string, db: AppDatabase): Promise<void> {
  await ensureSpreadsheetTabsExist(accessToken, spreadsheetId);

  const teamsRows = [
    ['ID', 'Name', 'City', 'Stadium', 'PrimaryColor', 'SecondaryColor', 'ManagerId', 'LeagueIds', 'PlayerIdsCount'],
    ...(db.teams || []).map(t => [
      t.id, t.name, t.city, t.stadium, t.primaryColor, t.secondaryColor, 
      t.managerId || '', (t.leagueIds || []).join(', '), (t.playerIds || []).length
    ])
  ];

  const personsRows = [
    ['ID', 'Name', 'Roles', 'Birthdate', 'Nationality', 'TeamIds', 'Rating', 'Goals', 'Assists', 'Points', 'PenaltyMinutes'],
    ...(db.persons || []).map(p => [
      p.id,
      p.name,
      (p.roles || []).join(', '),
      p.birthdate || '',
      p.nationality || '',
      (p.teamIds || []).join(', '),
      p.stats?.rating || 0,
      p.stats?.goals || 0,
      p.stats?.assists || 0,
      p.stats?.points || 0,
      p.stats?.penaltyMinutes || 0
    ])
  ];

  const matchesRows = [
    ['ID', 'LeagueID', 'HomeTeamID', 'AwayTeamID', 'Status', 'Date', 'HomeScore', 'AwayScore', 'Location', 'Ruleset'],
    ...(db.matches || []).map(m => [
      m.id,
      m.leagueId,
      m.homeTeamId,
      m.awayTeamId,
      m.status,
      m.date,
      m.homeScore ?? '',
      m.awayScore ?? '',
      m.location || '',
      m.ruleset || ''
    ])
  ];

  const calendarRows = [
    ['ID', 'Title', 'Type', 'Date', 'Time', 'Location', 'Description'],
    ...(db.calendarEvents || []).map(e => [
      e.id,
      e.title,
      e.type,
      e.date,
      e.time,
      e.location,
      e.description
    ])
  ];

  const leaguesRows = [
    ['ID', 'Name', 'Season', 'Region', 'OfficerId', 'TeamIds'],
    ...(db.leagues || []).map(l => [
      l.id, l.name, l.season, l.region, l.officerId || '', (l.teamIds || []).join(', ')
    ])
  ];

  const seasonsRows = [
    ['ID', 'Name', 'StartDate', 'EndDate', 'IsActive'],
    ...(db.seasons || []).map(s => [
      s.id, s.name, s.startDate, s.endDate, s.isActive ? 'TRUE' : 'FALSE'
    ])
  ];

  const divisionsRows = [
    ['ID', 'Name', 'PlayLevel'],
    ...(db.divisions || []).map(d => [
      d.id, d.name, d.playLevel
    ])
  ];

  const locationsRows = [
    ['ID', 'Name', 'Address', 'Capacity', 'HasRentals'],
    ...(db.association?.locations || []).map(loc => [
      loc.id, loc.name, loc.address, loc.capacity, loc.hasRentals ? 'TRUE' : 'FALSE'
    ])
  ];

  const settingsRows = [
    ['SettingKey', 'SettingValue'],
    ['Theme', db.settings?.generalSettings?.theme || 'light'],
    ['Language', db.settings?.generalSettings?.language || 'nl'],
    ['PeriodDurationMinutes', db.settings?.matchSettings?.periodDurationMinutes || 20],
    ['OvertimeEnabled', db.settings?.matchSettings?.overtimeEnabled ? 'TRUE' : 'FALSE'],
    ['AllowLoanPlayers', db.settings?.specificSettings?.allowLoanPlayers ? 'TRUE' : 'FALSE'],
    ['MaxPlayersPerTeam', db.settings?.specificSettings?.maxPlayersPerTeam || 20]
  ];

  const body = {
    valueInputOption: 'USER_ENTERED',
    data: [
      { range: 'Teams!A1', values: teamsRows },
      { range: 'Persons!A1', values: personsRows },
      { range: 'Matches!A1', values: matchesRows },
      { range: 'Calendar!A1', values: calendarRows },
      { range: 'Leagues!A1', values: leaguesRows },
      { range: 'Seasons!A1', values: seasonsRows },
      { range: 'Divisions!A1', values: divisionsRows },
      { range: 'Locations!A1', values: locationsRows },
      { range: 'Settings!A1', values: settingsRows }
    ]
  };

  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Fout bij exporteren naar Google Sheets');
  }
}

export async function importDbFromGoogleSheet(accessToken: string, spreadsheetId: string, currentDb: AppDatabase): Promise<AppDatabase> {
  await ensureSpreadsheetTabsExist(accessToken, spreadsheetId);

  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchGet?ranges=Teams!A1:Z100&ranges=Persons!A1:Z200&ranges=Matches!A1:Z200&ranges=Calendar!A1:Z200&ranges=Leagues!A1:Z50&ranges=Seasons!A1:Z50&ranges=Divisions!A1:Z50&ranges=Locations!A1:Z50&ranges=Settings!A1:Z50`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`
    }
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Fout bij importeren uit Google Sheets');
  }

  const data = await response.json();
  const valueRanges = data.valueRanges || [];

  const updatedDb = { ...currentDb };

  // Parse Teams
  const teamsData = valueRanges[0]?.values;
  if (teamsData && teamsData.length > 1) {
    const rows = teamsData.slice(1);
    updatedDb.teams = rows.map((r: any[]) => ({
      id: r[0] || `team-${Math.random()}`,
      name: r[1] || 'Team',
      city: r[2] || 'Groningen',
      stadium: r[3] || 'Kardinge',
      logo: '',
      primaryColor: r[4] || '#1E3A8A',
      secondaryColor: r[5] || '#FFFFFF',
      managerId: r[6] || null,
      leagueIds: r[7] ? r[7].split(',').map((s: string) => s.trim()) : ['league-1'],
      playerIds: [],
      tactics: { style: 'Neutraal', powerplayFocus: 'Snelheid', aggression: 50 }
    }));
  }

  // Parse Persons (Players, Managers, Referees, etc.)
  const personsData = valueRanges[1]?.values;
  if (personsData && personsData.length > 1) {
    const rows = personsData.slice(1);
    updatedDb.persons = rows.map((r: any[]) => {
      const rolesStr = r[2] || 'Player';
      const roles = rolesStr.split(',').map((s: string) => s.trim()) as any[];
      return {
        id: r[0] || `person-${Math.random()}`,
        name: r[1] || 'Persoon',
        avatar: 'https://cdn.shopify.com/s/files/1/1038/7203/7203/files/placeholder_profile_male.png',
        birthdate: r[3] || '2000-01-01',
        nationality: r[4] || 'Nederlandse',
        bio: '',
        roles: roles.length > 0 ? roles : ['Player'],
        teamIds: r[5] ? r[5].split(',').map((s: string) => s.trim()) : [],
        stats: {
          gamesPlayed: 0,
          goals: Number(r[7]) || 0,
          assists: Number(r[8]) || 0,
          points: Number(r[9]) || 0,
          penaltyMinutes: Number(r[10]) || 0,
          rating: Number(r[6]) || 75,
          speed: 75,
          shooting: 75,
          passing: 75,
          defense: 75,
          physical: 75
        }
      };
    });
  }

  // Parse Matches
  const matchesData = valueRanges[2]?.values;
  if (matchesData && matchesData.length > 1) {
    const rows = matchesData.slice(1);
    updatedDb.matches = rows.map((r: any[]) => ({
      id: r[0] || `match-${Math.random()}`,
      leagueId: r[1] || 'league-1',
      homeTeamId: r[2] || '',
      awayTeamId: r[3] || '',
      status: (r[4] as any) || 'Gepland',
      date: r[5] || new Date().toISOString(),
      homeScore: r[6] !== '' && !isNaN(Number(r[6])) ? Number(r[6]) : undefined,
      awayScore: r[7] !== '' && !isNaN(Number(r[7])) ? Number(r[7]) : undefined,
      location: r[8] || 'Kardinge',
      ruleset: r[9] || 'Standard House League Rules',
      events: [],
      stats: {
        shotsOnGoal: { home: 0, away: 0 },
        faceoffWins: { home: 0, away: 0 },
        powerplays: { home: { opportunities: 0, goals: 0 }, away: { opportunities: 0, goals: 0 } }
      }
    }));
  }

  // Parse Calendar
  const calendarData = valueRanges[3]?.values;
  if (calendarData && calendarData.length > 1) {
    const rows = calendarData.slice(1);
    updatedDb.calendarEvents = rows.map((r: any[]) => ({
      id: r[0] || `cal-${Math.random()}`,
      title: r[1] || 'Evenement',
      type: (r[2] as any) || 'Training',
      date: r[3] || new Date().toISOString(),
      time: r[4] || '19:00',
      location: r[5] || 'Kardinge',
      description: r[6] || '',
      rsvps: {}
    }));
  }

  return updatedDb;
}

