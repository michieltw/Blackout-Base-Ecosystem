import { Team, AppDatabase } from '../types';
import { getDatabase, saveDatabase } from './DatabaseService';

export function updateTeamDetails(teamId: string, updates: Partial<Team>): AppDatabase {
  const db = getDatabase();
  db.teams = db.teams.map(t => {
    if (t.id === teamId) {
      const updated = { ...t, ...updates };
      
      // If manager changed, reflect in the Person record
      if (updates.managerId !== undefined && updates.managerId !== t.managerId) {
        // Clear old manager's link
        if (t.managerId) {
          db.persons = db.persons.map(p => 
            p.id === t.managerId ? { ...p, managedTeamId: undefined } : p
          );
        }
        // Set new manager's link
        if (updates.managerId) {
          const mId = updates.managerId;
          db.persons = db.persons.map(p => 
            p.id === mId ? { ...p, managedTeamId: teamId, roles: Array.from(new Set([...p.roles, 'Manager'])) } : p
          );
        }
      }
      
      return updated;
    }
    return t;
  });
  saveDatabase(db); return db;
}
