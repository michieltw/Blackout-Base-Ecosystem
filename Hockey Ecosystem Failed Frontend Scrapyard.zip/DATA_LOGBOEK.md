# Data Logboek - IJshockey Manager (Blackout GHL)

Dit logboek registreert alle hardcoded waarden, entiteiten en configuraties in de applicatie die in de definitieve productieversie uit de database (Google Sheets via Google Apps Script) afkomstig moeten zijn.

---

## 1. Teams & Verenigingen

### "IJshockey Den Haag" / "Hijs Hokij"
- **Type**: Team / Vereniging
- **Context**: Wordt gebruikt als hoofdteam in het dashboard, teamselecties en competitieoverzichten.
- **Waarom**: Teamnamen, kleuren, logo's en verenigingsgegevens moeten dynamisch uit Google Sheets geladen kunnen worden.

### "UNIS Flyers Heerenven", "Tilburg Trappers", "GIJS Groningen", "Uithof Destroyers"
- **Type**: Tegenstanders / Teams in de competitie
- **Context**: Worden gebruikt in wedstrijdplanning, standen en statistieken.
- **Waarom**: Competitiedeelnemers veranderen per seizoen en moeten centraal beheerd worden in Google Sheets.

---

## 2. Spelers, Coaches & Officials (Persons)

### Spelersgegevens (Namen, Rugnummers, Posities, Ratings)
- **Type**: Speler / Persoon
- **Context**: Spelersroster, opstellingen, line-ups, statistieken (goals, assists, penalty's).
- **Waarom**: Spelersstatistieken en selecties wijzigen constant en horen thuis in een relationele Google Sheet ('Persons').

### Coaches & Teammanagers
- **Type**: Coach / Staf
- **Context**: Beheer van tactiek, wissels en teaminstellingen.
- **Waarom**: Niet elke coach is tevens speler; rollen en rechten moeten flexibel uit de database komen.

---

## 3. Competities, Seizoenen & Divisies

### "Eredivisie IJshockey" / "1e Divisie"
- **Type**: Competitie / League
- **Context**: Hoofdindeling van de competities en bekertoernooien.
- **Waarom**: Competitiestructuur en niveau-indelingen veranderen per sportjaar.

### "2025-2026"
- **Type**: Seizoen
- **Context**: Huidige actieve speelseizoen in de planner en standen.
- **Waarom**: Historische seizoenen moeten gearchiveerd kunnen worden.

---

## 4. Speellocaties & Stadions

### "Kardinge" (Groningen), "Thialf" (Heerenveen), "De Uithof" (Den Haag), "Stappegoor" (Tilburg)
- **Type**: Locatie / Sportaccommodatie
- **Context**: Wordt gekoppeld aan thuiswedstrijden en kalenderitems.
- **Waarom**: Accommodaties, capaciteit en faciliteiten kunnen wijzigen.

---

## 5. Wedstrijdinstellingen & Configuratie

### "PeriodDurationMinutes" (20 min) & Overtime Regels
- **Type**: Wedstrijdinstelling
- **Context**: Duur van periodes, straffen en verlenging tijdens live wedstrijdregistratie.
- **Waarom**: Spelreglementen kunnen per competitie verschillen.

### RSVP Status & Kalender Planning
- **Type**: Planning / Aanwezigheid
- **Context**: Trainingen en evenementen opkomst.
- **Waarom**: Spelersaanwezigheid moet live opgeslagen worden in de cloud.
