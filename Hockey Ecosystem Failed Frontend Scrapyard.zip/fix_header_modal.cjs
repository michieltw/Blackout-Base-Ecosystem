const fs = require('fs');
let text = fs.readFileSync('src/components/Header.tsx', 'utf8');

let start = text.indexOf('{showPasswordModal && (');
if (start !== -1) {
  let braces = 0;
  let end = start;
  for (let i = start; i < text.length; i++) {
    if (text[i] === '{') braces++;
    if (text[i] === '}') {
      braces--;
      if (braces === 0) {
        end = i;
        break;
      }
    }
  }
  text = text.substring(0, start) + text.substring(end + 1);
  fs.writeFileSync('src/components/Header.tsx', text);
}
