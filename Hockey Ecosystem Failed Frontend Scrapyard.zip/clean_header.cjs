const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf8');

// Remove onToggleDeveloperMode: (value: boolean) => void;
content = content.replace(/\s*onToggleDeveloperMode:\s*\(value:\s*boolean\)\s*=>\s*void;/g, '');

// Remove onToggleDeveloperMode,
content = content.replace(/\s*onToggleDeveloperMode,/g, '');

// Replace easterEgg logic
content = content.replace(/const toggleEasterEgg[\s\S]*?};\n/g, '');
content = content.replace(/onClick=\{toggleEasterEgg\}/g, '');

// Remove the Developer mode uitzetten button block
content = content.replace(/<button[^>]*>\s*<Code className="w-3\.5 h-3\.5"\s*\/>\s*Developer Mode Uitzetten\s*<\/button>/g, '');

// Also remove the `easterEggClicks` state if it exists
content = content.replace(/const \[easterEggClicks, setEasterEggClicks\] = useState\(0\);\n/g, '');

fs.writeFileSync('src/components/Header.tsx', content);
