const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else {
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let original = content;

  // Remove DevWidget imports
  content = content.replace(/import\s+\{?\s*DevWidget\s*\}?\s+from\s+['"].*?['"];?\n?/g, '');

  // Remove <DevWidget ...> tags but keep children
  // <DevWidget[^>]*> (match opening tag)
  // </DevWidget> (match closing tag)
  content = content.replace(/<DevWidget[^>]*>/g, '');
  content = content.replace(/<\/DevWidget>/g, '');

  if (content !== original) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${file}`);
  }
});
