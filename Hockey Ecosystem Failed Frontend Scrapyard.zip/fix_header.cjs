const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf8');

const devModeStart = content.indexOf('{/* Right: Developer Mode Button');
if (devModeStart !== -1) {
  const dropdownEnd = content.indexOf('</div>', devModeStart);
  // Wait, it's a bit hard to find the exact end of the block.
  // The block is:
  // <div className="flex items-center space-x-3">
  //   {db.currentUser?.systemRole === 'MultiLeagueOfficer' || ? ( ... )}
  //   {/* User Profile / Logout */}
  //   ...
}

// Better way is to use regex for the syntax errors.
// {db.currentUser?.systemRole === 'MultiLeagueOfficer' || ? (
content = content.replace(/\{db\.currentUser\?\.systemRole === 'MultiLeagueOfficer' \|\| \? \(/g, '{false ? (');
content = content.replace(/\{ \? 'text-slate-900 animate-pulse' : 'text-slate-500'\}/g, "'text-slate-500'");
content = content.replace(/\{ \? 'text-white' : 'text-slate-950'\}/g, "'text-slate-950'");
content = content.replace(/\{ \? 'Dev Mode Actief' : 'Developer Mode'\}/g, "'Developer Mode'");
content = content.replace(/\{ \? 'text-slate-900 font-mono' : 'text-slate-500'\}/g, "'text-slate-500'");
content = content.replace(/\{ \? 'Live Flow' : 'Admin Grendel'\}/g, "'Admin Grendel'");
content = content.replace(/\{ \? 'text-slate-900' : 'text-slate-600'\}/g, "'text-slate-600'");
content = content.replace(/\{ && showDevDropdown && \(/g, '{false && (');
content = content.replace(/\$\{ \? 'bg-slate-100 border-slate-200 text-slate-900 hover:bg-slate-100\/60 shadow-\[2px_2px_0px_0px_rgba\(6,182,212,1\)\]'/g, "${false ? ''");

fs.writeFileSync('src/components/Header.tsx', content);

// For other files, let's fix the broken destructurings.
const files = [
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  // error TS1180: Property destructuring pattern expected.
  // error TS1005: ':' expected.
  // This is because it looks like: export const LeagueOfficerDashboard: React.FC<LeagueOfficerDashboardProps> = ({ db, onUpdateDb,  = false }) => {
  text = text.replace(/,\s*=\s*(false|true)\s*/g, '');
  
  // For JSX tags, we had:
  // <SomeTag ... >
  // which might have been left with something like `<SomeTag dataFlow="..." >`
  // And the regex `content.replace(/\s*isDeveloperMode(\s|>|\/)/g, '$1');` might have broken something else?
  // Let's check `MultiLeagueOfficerDashboard.tsx`
  // `error TS1005: ')' expected.` at (122,17)
  fs.writeFileSync(file, text);
});

