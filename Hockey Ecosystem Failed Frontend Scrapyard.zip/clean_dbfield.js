const fs = require('fs');

function parseDbField(content) {
  let result = content;
  // We'll iterate through all instances of `<DbField`
  let index = result.indexOf('<DbField');
  while (index !== -1) {
    // Find the end of the self-closing tag `/>`
    let endIndex = result.indexOf('/>', index);
    if (endIndex === -1) break;
    endIndex += 2; // include `/>`

    const tagContent = result.substring(index, endIndex);
    
    // Find value={
    const valueMatch = tagContent.match(/value=\{([\s\S]*)\}\s+isDeveloperMode/);
    if (valueMatch) {
      let value = valueMatch[1].trim();
      // the regex might match too much if there are multiple tags, let's be careful.
      // A safer way is to find `value={` and then count curly braces to find the end.
      let vIndex = tagContent.indexOf('value={');
      if (vIndex !== -1) {
        let braces = 0;
        let startMatch = vIndex + 7;
        let endMatch = -1;
        for (let i = startMatch; i < tagContent.length; i++) {
          if (tagContent[i] === '{') braces++;
          if (tagContent[i] === '}') {
            if (braces === 0) {
              endMatch = i;
              break;
            } else {
              braces--;
            }
          }
        }
        
        if (endMatch !== -1) {
          let expr = tagContent.substring(startMatch, endMatch).trim();
          
          // Replace `<DbField ... />` with `expr` or `{expr}`.
          // If expr starts with `<` and ends with `>`, we don't need `{}` 
          // (assuming it's a JSX element)
          if (expr.startsWith('<') && expr.endsWith('>')) {
            result = result.substring(0, index) + expr + result.substring(endIndex);
          } else {
            result = result.substring(0, index) + `{${expr}}` + result.substring(endIndex);
          }
          
          index = result.indexOf('<DbField'); // restart finding
          continue;
        }
      }
    }
    
    // If we failed to parse, just move to the next
    index = result.indexOf('<DbField', index + 1);
  }
  
  // Remove import
  result = result.replace(/import\s+\{?\s*DbField\s*\}?\s+from\s+['"].*?['"];?\n?/g, '');
  
  return result;
}

const file = 'src/components/CompetitieDashboard.tsx';
let content = fs.readFileSync(file, 'utf8');
let newContent = parseDbField(content);
if (content !== newContent) {
  fs.writeFileSync(file, newContent);
  console.log('Updated ' + file);
}
