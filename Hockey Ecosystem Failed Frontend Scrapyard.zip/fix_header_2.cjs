const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf8');

const devModeStart = content.indexOf('{/* Right: Developer Mode Button');
const nextBlock = content.indexOf('{/* User Profile / Logout */}', devModeStart);

if (devModeStart !== -1 && nextBlock !== -1) {
  content = content.substring(0, devModeStart) + content.substring(nextBlock);
  fs.writeFileSync('src/components/Header.tsx', content);
}
