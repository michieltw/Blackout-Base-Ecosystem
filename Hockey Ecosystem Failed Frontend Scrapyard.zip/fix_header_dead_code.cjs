const fs = require('fs');
let text = fs.readFileSync('src/components/Header.tsx', 'utf8');

text = text.replace(/  isDeveloperMode: boolean;\n/g, '');
text = text.replace(/  onToggleDeveloperMode: \(value: boolean\) => void;\n/g, '');

text = text.replace(/  const handleDevModeClick = \(\) => \{[\s\S]*?\};\n/g, '');
text = text.replace(/  const handlePasswordSubmit = \(e: React.FormEvent\) => \{[\s\S]*?\};\n/g, '');

fs.writeFileSync('src/components/Header.tsx', text);
