const fs = require('fs');

const files = [
  'src/components/CompetitieDashboard.tsx',
  'src/components/Dashboard.tsx',
  'src/components/LeagueOfficerDashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');
  
  // Rule 1: <tag attr="val"Text -> <tag attr="val">Text
  // matches `="something"` followed by a non-space, non-/, non-> character
  text = text.replace(/(="[^"]*")([^>\/\s])/g, '$1>$2');
  
  // Rule 2: <tag attr="val" <nextTag -> <tag attr="val"> <nextTag
  text = text.replace(/(="[^"]*")\s+(<[A-Za-z\/])/g, '$1>\n$2');

  // Rule 3: <tag attr="val" { -> <tag attr="val"> {
  text = text.replace(/(="[^"]*")\s+(\{)/g, '$1>$2');
  
  fs.writeFileSync(file, text);
});
