const fs = require('fs');

const files = [
  'src/components/Dashboard.tsx',
  'src/components/ManagerDashboard.tsx',
  'src/components/MultiLeagueOfficerDashboard.tsx',
  'src/components/ProfileSection.tsx',
  'src/components/StandardUserDashboard.tsx'
];

files.forEach(file => {
  let text = fs.readFileSync(file, 'utf8');

  // Fix `<input ... >` or `<input ... \n` missing `/>`
  // Actually, wait, it's `<img ... >` missing closing tags.
  // We can just use a simple state machine to find `<img` and `<input` and ensure they close with `/>`.
  
  function fixSelfClosing(tagName) {
    let result = '';
    let i = 0;
    while (i < text.length) {
      const idx = text.indexOf(`<${tagName} `, i);
      if (idx === -1) {
        result += text.substring(i);
        break;
      }
      result += text.substring(i, idx);
      
      // Find the end of the tag
      let endIdx = idx;
      let inString = false;
      let stringChar = '';
      while (endIdx < text.length) {
        const c = text[endIdx];
        if (inString) {
          if (c === stringChar) {
            inString = false;
          }
        } else {
          if (c === '"' || c === "'") {
            inString = true;
            stringChar = c;
          } else if (c === '>') {
            break;
          }
        }
        endIdx++;
      }
      
      if (endIdx < text.length) {
        const tagContent = text.substring(idx, endIdx + 1);
        if (!tagContent.endsWith('/>')) {
           result += tagContent.substring(0, tagContent.length - 1) + ' />';
        } else {
           result += tagContent;
        }
      } else {
        result += text.substring(idx);
      }
      i = endIdx + 1;
    }
    text = result;
  }
  
  fixSelfClosing('img');
  fixSelfClosing('input');
  
  // What about textarea? It's not self-closing, but maybe some people wrote `<textarea />`
  // Actually, `<textarea ... >` needs `</textarea>` or `/>`
  // The error says "JSX element 'textarea' has no corresponding closing tag."
  // Which means it's missing `</textarea>` OR it was `<textarea ... />` and lost the `/`.
  fixSelfClosing('textarea');

  fs.writeFileSync(file, text);
});
