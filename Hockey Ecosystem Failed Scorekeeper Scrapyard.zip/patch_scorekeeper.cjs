const fs = require('fs');
const content = fs.readFileSync('src/components/ScorekeeperScreen.tsx', 'utf8');

const importRegex = /import GameSummaryModal from '.\/Scorekeeper\/GameSummaryModal';/;
let newContent = content.replace(importRegex, "import GameSummaryModal from './Scorekeeper/GameSummaryModal';\nimport PeriodEndModal from './Scorekeeper/PeriodEndModal';");

const stateRegex = /const \[toastMessage, setToastMessage\] = useState<string \| null>\(null\);/;
newContent = newContent.replace(stateRegex, "const [toastMessage, setToastMessage] = useState<string | null>(null);\n  const [showPeriodEndModal, setShowPeriodEndModal] = useState(false);\n  const prevTimeRef = useRef(gameState.timeRemaining);\n  const [rinkRotation, setRinkRotation] = useState(0);");

const effectTarget = `          if (newTime === 0 && config.settings?.autoStopAtPeriodEnd === 'Yes') {
             newIsRunning = false;
          }`;
const effectReplacement = `          if (newTime === 0 && config.settings?.autoStopAtPeriodEnd === 'Yes') {
             newIsRunning = false;
          }
          if (newTime === 0 && prev.timeRemaining > 0) {
             setTimeout(() => {
                setShowPeriodEndModal(true);
             }, 2000);
          }`;
newContent = newContent.replace(effectTarget, effectReplacement);

const returnRegex = /<GameSummaryModal\s+isOpen={showSummaryModal}/;
const returnReplacement = `{showPeriodEndModal && (
        <PeriodEndModal
          gameState={gameState}
          homeTeam={config.homeTeam}
          awayTeam={config.awayTeam}
          homeColor={config.homeColor}
          awayColor={config.awayColor}
          homeLogo={config.homeLogo}
          awayLogo={config.awayLogo}
          onResumeGame={(switchEnds) => {
            if (switchEnds) {
               setRinkRotation(prev => (prev + 180) % 360);
            }
            // Proceed to next period
            setGameState(prev => ({
               ...prev,
               period: prev.period + 1,
               timeRemaining: config.settings?.periodLength || 20 * 60,
               stoppageTime: 0
            }));
            setShowPeriodEndModal(false);
          }}
        />
      )}
      <GameSummaryModal
        isOpen={showSummaryModal}`;
newContent = newContent.replace(returnRegex, returnReplacement);

const rinkMapRegex = /<RinkMap\s+isRunning={gameState.isRunning}/;
const rinkMapReplacement = `<RinkMap
          rotation={rinkRotation}
          onRotate={(deg) => setRinkRotation(prev => (prev + deg) % 360)}
          isRunning={gameState.isRunning}`;
newContent = newContent.replace(rinkMapRegex, rinkMapReplacement);

if (newContent !== content) {
  fs.writeFileSync('src/components/ScorekeeperScreen.tsx', newContent);
  console.log("SUCCESS");
} else {
  console.log("NO CHANGES MADE");
}
