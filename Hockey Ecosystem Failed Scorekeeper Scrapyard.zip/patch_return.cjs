const fs = require('fs');
const content = fs.readFileSync('src/components/ScorekeeperScreen.tsx', 'utf8');

const returnTarget = `{/* Game Summary / End Game Modal */}
      <GameSummaryModal`;

const returnReplacement = `{showPeriodEndModal && (
        <PeriodEndModal
          gameState={gameState}
          homeTeam={config.homeTeam}
          awayTeam={config.awayTeam}
          homeColor={config.homeColor}
          awayColor={config.awayColor}
          homeLogo={config.homeLogo}
          awayLogo={config.awayLogo}
          onResumeGame={(switchEnds) => {
            if (switchEnds) {
               setRinkRotation(prev => (prev + 180) % 360);
            }
            setGameState(prev => {
              const nextPeriod = prev.period + 1;
              let nextTime = config.settings?.periodLength || 20 * 60;
              if (nextPeriod === 4) nextTime = 5 * 60; // OT is usually 5 mins
              if (nextPeriod >= 5) nextTime = 0; // Shootout has no time
              return {
               ...prev,
               period: nextPeriod,
               timeRemaining: nextTime,
               stoppageTime: 0
              };
            });
            setShowPeriodEndModal(false);
            setIsFaceoffMode(true);
          }}
        />
      )}

      {/* Game Summary / End Game Modal */}
      <GameSummaryModal`;

if (content.includes(returnTarget)) {
  fs.writeFileSync('src/components/ScorekeeperScreen.tsx', content.replace(returnTarget, returnReplacement));
  console.log("SUCCESS");
} else {
  console.log("NOT FOUND");
}
