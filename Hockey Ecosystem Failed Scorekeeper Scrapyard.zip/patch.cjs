const fs = require('fs');
const content = fs.readFileSync('src/components/Scorekeeper/ScoreHeader.tsx', 'utf8');

const target = `  const [startY, setStartY] = useState<number | null>(null);
  const [homeLogoError, setHomeLogoError] = useState(false);
  const [awayLogoError, setAwayLogoError] = useState(false);

  const handleTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    if ('touches' in e) {
      setStartY(e.touches[0].clientY);
    } else {
      setStartY((e as React.MouseEvent).clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (startY === null || !onAdjustTime) return;
    let clientY;
    if ('touches' in e) {
      clientY = e.touches[0].clientY;
    } else {
      clientY = (e as React.MouseEvent).clientY;
    }

    const diff = startY - clientY;

    // UI-Thresholds (zoals 20px swipe) zijn logistiek, geen domeindata
    if (diff > 20) {
      onAdjustTime(1);
      setStartY(clientY);
    } else if (diff < -20) {
      onAdjustTime(-1);
      setStartY(clientY);
    }
  };

  const handleTouchEnd = () => {
    setStartY(null);
  };`;

const replacement = `  const [initialY, setInitialY] = useState<number | null>(null);
  const [lastAccumulated, setLastAccumulated] = useState<number>(0);
  const [homeLogoError, setHomeLogoError] = useState(false);
  const [awayLogoError, setAwayLogoError] = useState(false);

  const handleTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    let clientY;
    if ('touches' in e) {
      clientY = e.touches[0].clientY;
    } else {
      clientY = (e as React.MouseEvent).clientY;
    }
    setInitialY(clientY);
    setLastAccumulated(0);
  };

  const handleTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (initialY === null || !onAdjustTime) return;

    let clientY;
    if ('touches' in e) {
      clientY = e.touches[0].clientY;
    } else {
      clientY = (e as React.MouseEvent).clientY;
    }

    const diff = initialY - clientY;
    
    // Exponential scale for smoother precision at small swipes, and faster changes at long swipes
    const absDiff = Math.abs(diff);
    const sign = diff > 0 ? 1 : -1;
    
    let totalSeconds = 0;
    if (absDiff > 10) {
      totalSeconds = Math.floor(Math.pow(absDiff / 10, 1.5));
    }

    const currentAccumulated = totalSeconds * sign;
    const delta = currentAccumulated - lastAccumulated;

    if (delta !== 0) {
      onAdjustTime(delta);
      setLastAccumulated(currentAccumulated);
    }
  };

  const handleTouchEnd = () => {
    setInitialY(null);
    setLastAccumulated(0);
  };`;

const index = content.indexOf('  const [startY, setStartY] = useState<number | null>(null);');
if (index === -1) {
  console.log("NOT FOUND");
} else {
  const endIndex = content.indexOf('  };', content.indexOf('const handleTouchEnd')) + 4;
  const newContent = content.substring(0, index) + replacement + content.substring(endIndex);
  fs.writeFileSync('src/components/Scorekeeper/ScoreHeader.tsx', newContent);
  console.log("SUCCESS");
}
