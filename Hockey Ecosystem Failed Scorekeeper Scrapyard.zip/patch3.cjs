const fs = require('fs');
const content = fs.readFileSync('src/components/SettingsScreen.tsx', 'utf8');

const target1 = `  const [periodLength, setPeriodLength] = useState(contract.defaultPeriodLength);`;
const replacement1 = `  const [periodLength, setPeriodLength] = useState(contract.defaultPeriodLength);
  const [p1Input, setP1Input] = useState(\`\${contract.defaultPeriodLength.toString().padStart(2, '0')}:00\`);`;

const target2 = `        if (defaults) {
          if (defaults.periodLength !== undefined) setPeriodLength(Math.round(defaults.periodLength / 60));`;
const replacement2 = `        if (defaults) {
          if (defaults.periodLength !== undefined) {
             const mins = Math.round(defaults.periodLength / 60);
             setPeriodLength(mins);
             setP1Input(\`\${mins.toString().padStart(2, '0')}:00\`);
          }`;

const target3 = `        if (defaultsStr) {
          const defaults = JSON.parse(defaultsStr);
          if (defaults.periodLength !== undefined) setPeriodLength(defaults.periodLength);`;
const replacement3 = `        if (defaultsStr) {
          const defaults = JSON.parse(defaultsStr);
          if (defaults.periodLength !== undefined) {
             setPeriodLength(defaults.periodLength);
             setP1Input(\`\${defaults.periodLength.toString().padStart(2, '0')}:00\`);
          }`;

const target4 = `                {contract.periodBlocks.map((block) => (
                  <div key={block.id} className="flex flex-col gap-1">
                    <label className="font-mono text-[10px] font-bold text-on-surface-variant uppercase">{block.label}</label>
                    <input 
                      className="w-full bg-[#050505] border border-[#2A2A2A] rounded p-2 text-on-background text-center font-display font-bold text-[24px] input-focus outline-none" 
                      type="text" 
                      defaultValue={block.id === 'p1' && periodLength !== undefined ? \`\${periodLength.toString().padStart(2, '0')}:00\` : block.defaultTime} 
                      onChange={(e) => {
                        if (block.id === 'p1') {
                          const val = e.target.value;
                          const parts = val.split(':');
                          if (parts.length > 0) {
                            const mins = parseInt(parts[0], 10);
                            if (!isNaN(mins)) {
                              setPeriodLength(mins);
                            }
                          }
                        }
                      }}
                    />
                  </div>
                ))}`;

const replacement4 = `                {contract.periodBlocks.map((block) => (
                  <div key={block.id} className="flex flex-col gap-1">
                    <label className="font-mono text-[10px] font-bold text-on-surface-variant uppercase">{block.label}</label>
                    {block.id === 'p1' ? (
                      <input 
                        className="w-full bg-[#050505] border border-[#2A2A2A] rounded p-2 text-on-background text-center font-display font-bold text-[24px] input-focus outline-none" 
                        type="text" 
                        value={p1Input}
                        onChange={(e) => {
                          const val = e.target.value;
                          setP1Input(val);
                          const parts = val.split(':');
                          if (parts.length > 0) {
                            const mins = parseInt(parts[0], 10);
                            if (!isNaN(mins)) {
                              setPeriodLength(mins);
                            }
                          }
                        }}
                      />
                    ) : (
                      <input 
                        className="w-full bg-[#050505] border border-[#2A2A2A] rounded p-2 text-on-background text-center font-display font-bold text-[24px] input-focus outline-none" 
                        type="text" 
                        defaultValue={block.defaultTime} 
                      />
                    )}
                  </div>
                ))}`;

let newContent = content.replace(target1, replacement1);
newContent = newContent.replace(target2, replacement2);
newContent = newContent.replace(target3, replacement3);
newContent = newContent.replace(target4, replacement4);

if (newContent !== content) {
  fs.writeFileSync('src/components/SettingsScreen.tsx', newContent);
  console.log("SUCCESS");
} else {
  console.log("NOT FOUND");
}
